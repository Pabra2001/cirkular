const searchCache = new Map();
let ebayTokenCache = { token: null, expiresAt: 0 };

function decodeHtml(str) {
  return String(str || "")
    .replace(/&amp;/g, "&")
    .replace(/&quot;/g, '"')
    .replace(/&#39;|&apos;/g, "'")
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">")
    .replace(/\s+/g, " ")
    .trim();
}

const CATEGORY_GROUPS = [
  ["jacket", "coat", "blazer", "bomber", "parka", "trench", "windbreaker", "puffer", "anorak", "vest"],
  ["sweater", "cardigan", "knit", "hoodie", "sweatshirt", "pullover", "fleece", "jumper"],
  ["jeans", "denim", "pants", "trousers", "chinos", "joggers", "leggings", "shorts"],
  ["dress", "gown", "midi", "maxi", "mini dress", "romper", "jumpsuit"],
  ["skirt", "miniskirt"],
  ["shirt", "tee", "t-shirt", "top", "blouse", "tank", "polo", "camisole", "bodysuit"],
  ["shoe", "shoes", "sneaker", "sneakers", "boot", "boots", "loafer", "heel", "sandal", "clog", "mule"],
  ["bag", "tote", "purse", "backpack", "crossbody", "clutch", "wallet"],
  ["hat", "cap", "beanie", "beret", "bucket hat", "scarf", "gloves", "belt", "sunglasses"]
];

function detectCategoryIndex(text) {
  const lower = String(text || "").toLowerCase();
  for (let i = 0; i < CATEGORY_GROUPS.length; i++) {
    if (CATEGORY_GROUPS[i].some((kw) => new RegExp(`\\b${kw}s?\\b`, "i").test(lower))) {
      return i;
    }
  }
  return -1;
}

function isCategoryCompatible(queryCatIdx, listingTitle) {
  if (queryCatIdx < 0) return true;
  const listingCatIdx = detectCategoryIndex(listingTitle);
  // Reject if the listing clearly belongs to a different garment category (e.g. hat when shopping for jacket)
  if (listingCatIdx >= 0 && listingCatIdx !== queryCatIdx) return false;
  return true;
}

const SPAM_LISTING_RE = /\b(black friday|cyber monday|closet sale|% off|do not buy|not for sale|iso\b|in search of|bundle|promo|giveaway|live show|host pick)\b/i;

function findGarmentWord(text) {
  const lower = String(text || "").toLowerCase();
  for (const group of CATEGORY_GROUPS) {
    for (const kw of group) {
      if (new RegExp(`\\b${kw}s?\\b`, "i").test(lower)) return kw;
    }
  }
  return "";
}

const STYLE_KEYWORDS = [
  "tabi", "split-toe", "split toe", "chelsea", "combat", "western", "cowboy", "motorcycle", "moto",
  "ankle", "knee-high", "knee high", "thigh-high", "platform", "wedge", "stiletto", "kitten", "chunky",
  "mary jane", "ballet", "slingback", "penny", "oxford", "derby", "brogue", "espadrille",
  "cargo", "carpenter", "parachute", "pleated", "wide-leg", "wide leg", "flared", "bootcut", "straight", "baggy", "skinny",
  "cropped", "oversized", "fitted", "boxy", "relaxed", "tailored", "structured", "draped", "wrap", "corset", "peplum",
  "halter", "backless", "off-shoulder", "strapless", "one-shoulder", "turtleneck", "mock-neck", "mock neck", "v-neck", "crewneck", "bow",
  "trench", "puffer", "bomber", "biker", "varsity", "quilted", "shearling", "peacoat", "double-breasted",
  "leather", "suede", "denim", "linen", "silk", "satin", "velvet", "corduroy", "tweed", "cashmere", "wool", "mohair", "mesh", "lace", "chiffon", "organza", "ribbed", "crochet", "knit", "sequin",
  "floral", "striped", "plaid", "checkered", "gingham", "polka", "paisley", "printed", "embroidered",
  "argyle", "fair isle", "cable", "houndstooth", "herringbone", "leopard", "zebra", "camo", "tie-dye", "colorblock", "ruffle", "tiered", "smocked", "funnel"
];

function extractStyleKeywords(text) {
  const lower = String(text || "").toLowerCase();
  const found = [];
  for (const kw of STYLE_KEYWORDS) {
    if (new RegExp(`\\b${kw.replace(/[- ]/g, "[-\\s]?")}\\b`, "i").test(lower)) {
      found.push(kw);
    }
  }
  return found;
}

const ALL_COLOR_WORDS_RE = /\b(black|charcoal|noir|onyx|white|ivory|cream|ecru|off-white|gray|grey|heather|slate|brown|taupe|chocolate|espresso|camel|beige|khaki|sand|navy|blue|indigo|cobalt|green|olive|sage|emerald|forest|pink|rose|blush|magenta|red|burgundy|maroon|crimson|wine|purple|lavender|lilac|plum|orange|rust|terracotta|yellow|mustard|gold|silver)\b/gi;

function buildCleanQuery(rawTitle, brand, overrideColor = "", contextText = "") {
  const stopWords = /\b(new|with|tags|nwt|nwot|free|shipping|sale|off|limited|edition|official|store|shop|online|men's|women's|mens|womens|selected|items|display|army|genuine|real|pure|100%|vegan|faux|full-grain|top-grain|cm|mm|inch|inches|heel|heels|collection|zw|trf|look|outfit)\b/gi;
  const garment = findGarmentWord(rawTitle) || findGarmentWord(contextText);

  let q = String(rawTitle || "");
  // Strip store/brand name from generic query so indie brands don't crowd out style keywords
  if (brand && brand.length > 1) {
    const escapedBrand = brand.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
    q = q.replace(new RegExp(`\\b${escapedBrand}\\b`, "gi"), " ");
  }
  // If a live color swatch is selected, strip any stale color words from the product title
  if (overrideColor) {
    q = q.replace(ALL_COLOR_WORDS_RE, " ");
  }
  // Normalize animal-hide prefixes ("cow leather" -> "leather", "calfskin" -> "leather") so "cow" never triggers cow-print
  q = q
    .replace(/\b\d+\s*%/g, " ")
    .replace(/\b(cow|calf|lamb|goat|sheep|pig|bull|steer|horse)\s+(leather|suede|hide|skin)\b/gi, "$2")
    .replace(/\b(calfskin|lambskin|cowhide|sheepskin|goatskin)\b/gi, "leather")
    .replace(/\b\d+(?:\.\d+)?\s*(?:cm|mm|in|inch|inches|")\b/gi, " ")
    .replace(/[|–—•·/\\()[\]]/g, " ")
    .replace(stopWords, " ");

  const styleHits = extractStyleKeywords(q);
  // Pull up to 2 fallback style/material descriptors from page context if the title is sparse
  if (styleHits.length < 2 && contextText) {
    for (const kw of extractStyleKeywords(contextText)) {
      if (!styleHits.includes(kw)) styleHits.push(kw);
      if (styleHits.length >= 2) break;
    }
  }
  const words = q
    .trim()
    .split(/\s+/)
    .filter((w) => w.length > 1 && w.toLowerCase() !== garment && !/^\d+$/.test(w));

  // Build prioritized query: signature style keywords first (e.g. "tabi", "leather"), then remaining descriptive words, then garment
  const core = [];
  const added = new Set();
  const pushUnique = (w) => {
    const low = w.toLowerCase();
    if (!low || low === garment || added.has(low)) return;
    added.add(low);
    core.push(w);
  };

  for (const kw of styleHits) {
    if (core.length >= 3) break;
    pushUnique(kw);
  }
  for (const w of words) {
    if (core.length >= (garment ? 3 : 4)) break;
    pushUnique(w);
  }
  if (garment) core.push(garment);
  return core.join(" ");
}

function extractSize(block, title) {
  const htmlMatch =
    block.match(/Size:\s*([^<\n"]{1,18})/i) ||
    block.match(/tile__details__pipe__size[^>]*>\s*(?:Size:\s*)?([^<\n"]{1,18})/i);
  if (htmlMatch) return decodeHtml(htmlMatch[1]);

  // Poshmark tile-grid-redesign puts the size token right after the price ($XX | [$YY] | SIZE)
  const plain = block.slice(0, 6000).replace(/<[^>]+>/g, " | ").replace(/\s+/g, " ");
  const afterPrice = plain.match(/\$\s*[0-9][0-9,]*(?:\.[0-9]{2})?(?:\s*\|\s*\$\s*[0-9][0-9,]*(?:\.[0-9]{2})?)*\s*(?:\|\s*)+([A-Za-z0-9.\/ ×-]{1,14})\s*\|/);
  if (afterPrice) {
    const cand = afterPrice[1].trim();
    if (/^(?:(?:US|EU|UK)\s*)?(?:XXS|XS|S|M|L|XL|XXL|2XL|3XL|XS\/S|S\/M|M\/L|L\/XL|OS|ONE SIZE|FREE|[0-9]{1,2}(?:\.[05])?|[0-9]{2}\s*[x×]\s*[0-9]{2}|[0-9]{1,2}[PSWL]?)$/i.test(cand)) {
      return cand.toUpperCase();
    }
  }

  const t = String(title || "");
  const dimMatch = t.match(/\b(\d{2}\s*[x×]\s*\d{2})\b/i);
  if (dimMatch) return dimMatch[1].replace(/\s+/g, " ");

  const explicitMatch = t.match(/\b(?:size|sz\.?)\s*([0-9]{1,2}(?:\.[05])?|XXS|XS|S|M|L|XL|XXL|2XL|3XL|OS)\b/i);
  if (explicitMatch) return explicitMatch[1].toUpperCase();

  const euUsMatch = t.match(/\b((?:US|EU|UK)\s*[0-9]{1,2}(?:\.[05])?)\b/i);
  if (euUsMatch) return euUsMatch[1].toUpperCase();

  const genderSizeMatch = t.match(/\b(?:men'?s|women'?s|mens|womens)\s+(XXS|XS|S|M|L|XL|XXL|2XL|3XL|[0-9]{1,2})\b/i);
  if (genderSizeMatch) return genderSizeMatch[1].toUpperCase();

  const trailingSize = t.match(/[\s,\-|]+(XXS|XS|S|M|L|XL|XXL|2XL|3XL)(?:\s*$)/i);
  if (trailingSize) return trailingSize[1].toUpperCase();

  return "See listing";
}

function parsePoshmarkTiles(html, query, retailPrice, department = "") {
  const listings = [];
  const seenUrls = new Set();
  const queryCatIdx = detectCategoryIndex(query);
  const blocks = html.split("tile-grid-redesign__media--wrapper").slice(1, 55);

  for (const block of blocks) {
    const hrefMatch = block.match(/href="(\/listing\/[^"]+)"/);
    const imgMatch =
      block.match(/<img[^>]+src="(https:\/\/di2ponv0v5otw\.cloudfront\.net\/posts\/[^"]+)"[^>]*alt="([^"]*)"/i) ||
      block.match(/<img[^>]+alt="([^"]*)"[^>]*src="(https:\/\/di2ponv0v5otw\.cloudfront\.net\/posts\/[^"]+)"/i);

    if (!hrefMatch || !imgMatch) continue;

    const url = `https://poshmark.com${hrefMatch[1]}`;
    if (seenUrls.has(url)) continue;

    const isSrcFirst = imgMatch[1].startsWith("http");
    const image = isSrcFirst ? imgMatch[1] : imgMatch[2];
    const title = decodeHtml(isSrcFirst ? imgMatch[2] : imgMatch[1]);
    if (!title || !image) continue;
    if (SPAM_LISTING_RE.test(title)) continue;
    if (!isCategoryCompatible(queryCatIdx, title)) continue;
    if (!isGenderCompatible(department, title)) continue;

    const priceMatch = block.match(/\$\s*([0-9][0-9,]*(?:\.[0-9]{2})?)/);
    const priceNum = priceMatch ? parseFloat(priceMatch[1].replace(/,/g, "")) : null;
    if (!priceNum || priceNum <= 0) continue;
    if (retailPrice && priceNum >= retailPrice) continue;

    const size = extractSize(block, title);

    const brandMatch =
      block.match(/tile__details__pipe__brand[^>]*>([^<]+)</i) ||
      block.match(/href="\/brand\/[^"]*"[^>]*>([^<]+)</i);
    const brand = brandMatch ? decodeHtml(brandMatch[1]) : "Secondhand";

    seenUrls.add(url);
    listings.push({
      name: title.length > 52 ? title.slice(0, 49).trim() + "…" : title,
      price: `$${priceNum.toFixed(2)}`,
      priceNum,
      source: "Poshmark",
      labels: ["Listed size", "Condition", "Brand", "Source"],
      facts: [size, "Pre-owned", brand, "Poshmark"],
      why: `${brand !== "Secondhand" ? `${brand} · ` : ""}Pre-owned${size !== "See listing" ? `, size ${size}` : ""}. Loading seller notes…`,
      url,
      image
    });

    if (listings.length >= 15) break;
  }

  return listings;
}

function parseTheRealRealTiles(html, query, retailPrice) {
  const listings = [];
  const seenUrls = new Set();
  const queryCatIdx = detectCategoryIndex(query);
  const blocks = html.split('data-testid="plp-product/').slice(1, 30);

  for (const block of blocks) {
    const hrefMatch = block.match(/href="(\/products\/[^"]+)"/);
    const imgMatch = block.match(/https:\/\/product-images\.therealreal\.com\/[A-Za-z0-9_.-]+\.(?:jpg|jpeg|png)/i);
    const altMatch = block.match(/<img[^>]+alt="([^"]{3,120})"/i);
    const priceMatch = block.match(/\$\s*([0-9][0-9,]*(?:\.[0-9]{2})?)/);

    if (!hrefMatch || !imgMatch || !altMatch || !priceMatch) continue;

    const url = `https://www.therealreal.com${hrefMatch[1]}`;
    if (seenUrls.has(url)) continue;

    const priceNum = parseFloat(priceMatch[1].replace(/,/g, ""));
    if (!priceNum || priceNum <= 0) continue;
    if (retailPrice && priceNum >= retailPrice) continue;

    const title = decodeHtml(altMatch[1]);
    if (!isCategoryCompatible(queryCatIdx, title)) continue;
    const size = extractSize(block, title);
    seenUrls.add(url);
    listings.push({
      name: title.length > 52 ? title.slice(0, 49).trim() + "…" : title,
      price: `$${priceNum.toFixed(2)}`,
      priceNum,
      source: "The RealReal",
      labels: ["Listed size", "Condition", "Authenticated", "Source"],
      facts: [size, "Consigned", "Yes", "The RealReal"],
      why: `Authenticated consignment piece on The RealReal${size !== "See listing" ? `, size ${size}` : ""}.`,
      url,
      image: `${imgMatch[0]}?auto=webp&width=360&quality=75`
    });

    if (listings.length >= 5) break;
  }

  return listings;
}

async function getEbayToken(clientId, clientSecret) {
  if (ebayTokenCache.token && Date.now() < ebayTokenCache.expiresAt) {
    return ebayTokenCache.token;
  }
  const creds = btoa(`${clientId}:${clientSecret}`);
  const res = await fetch("https://api.ebay.com/identity/v1/oauth2/token", {
    method: "POST",
    headers: {
      Authorization: `Basic ${creds}`,
      "Content-Type": "application/x-www-form-urlencoded"
    },
    body: "grant_type=client_credentials&scope=https%3A%2F%2Fapi.ebay.com%2Foauth%2Fapi_scope"
  });
  if (!res.ok) throw new Error(`eBay auth ${res.status}`);
  const data = await res.json();
  ebayTokenCache = {
    token: data.access_token,
    expiresAt: Date.now() + (data.expires_in - 120) * 1000
  };
  return data.access_token;
}

async function imageToJpegBase64(imageUrl, maxDim = 512) {
  if (!imageUrl || typeof OffscreenCanvas === "undefined" || typeof createImageBitmap === "undefined") {
    return "";
  }
  try {
    const res = await fetch(imageUrl, { signal: AbortSignal.timeout(3000) });
    if (!res.ok) return "";
    const blob = await res.blob();
    const bitmap = await createImageBitmap(blob);
    const scale = Math.min(1, maxDim / Math.max(bitmap.width, bitmap.height));
    const w = Math.max(32, Math.round(bitmap.width * scale));
    const h = Math.max(32, Math.round(bitmap.height * scale));
    const canvas = new OffscreenCanvas(w, h);
    const ctx = canvas.getContext("2d");
    ctx.drawImage(bitmap, 0, 0, w, h);
    bitmap.close?.();
    const outBlob = await canvas.convertToBlob({ type: "image/jpeg", quality: 0.84 });
    const dataUrl = await blobToDataUrl(outBlob);
    return dataUrl.replace(/^data:image\/jpeg;base64,/, "");
  } catch {
    return "";
  }
}

async function searchEbayByImage(productImage, retailPrice, query, department = "", color = "") {
  const { ebayClientId, ebayClientSecret } = await chrome.storage.local.get([
    "ebayClientId",
    "ebayClientSecret"
  ]);
  if (!ebayClientId || !ebayClientSecret || !productImage) return [];

  const base64 = await imageToJpegBase64(productImage, 512);
  if (!base64) return [];

  const token = await getEbayToken(ebayClientId, ebayClientSecret);
  const priceFilter = retailPrice ? `,price:[1..${Math.max(1, Math.floor(retailPrice - 1))}],priceCurrency:USD` : "";
  const url = `https://api.ebay.com/buy/browse/v1/item_summary/search_by_image?filter=conditions:{USED}${priceFilter}&limit=8`;

  const res = await fetch(url, {
    method: "POST",
    headers: {
      Authorization: `Bearer ${token}`,
      "Content-Type": "application/json",
      "X-EBAY-C-MARKETPLACE-ID": "EBAY_US"
    },
    body: JSON.stringify({ image: base64 }),
    signal: AbortSignal.timeout(6000)
  });
  if (!res.ok) return [];
  const data = await res.json();
  const items = data.itemSummaries || [];
  const queryCatIdx = detectCategoryIndex(query);

  return items
    .map((item) => {
      const priceNum = parseFloat(item.price?.value || "0");
      if (!priceNum || (retailPrice && priceNum >= retailPrice)) return null;
      const image = item.thumbnailImages?.[0]?.imageUrl || item.image?.imageUrl;
      const title = item.title || "";
      if (!image || !item.itemWebUrl || !title) return null;
      if (SPAM_LISTING_RE.test(title)) return null;
      if (!isCategoryCompatible(queryCatIdx, title)) return null;
      if (!isGenderCompatible(department, title)) return null;
      if (!isColorCompatible(color, title)) return null;
      return {
        name: title.length > 52 ? title.slice(0, 49).trim() + "…" : title,
        price: `$${priceNum.toFixed(2)}`,
        priceNum,
        source: "eBay",
        _visualSearchBoost: 12,
        labels: ["Condition", "Shipping", "Seller", "Source"],
        facts: [
          item.condition || "Pre-owned",
          item.shippingOptions?.[0]?.shippingCost?.value === "0.00" ? "Free" : "Check listing",
          item.seller?.username || "Verified",
          "eBay"
        ],
        why: `Visually matched pre-owned listing on eBay (${item.condition || "Pre-owned"}).`,
        url: item.itemWebUrl,
        image
      };
    })
    .filter(Boolean)
    .slice(0, 5);
}

async function searchEbay(query, retailPrice) {
  const { ebayClientId, ebayClientSecret } = await chrome.storage.local.get([
    "ebayClientId",
    "ebayClientSecret"
  ]);
  if (!ebayClientId || !ebayClientSecret) return [];

  const token = await getEbayToken(ebayClientId, ebayClientSecret);
  const priceFilter = retailPrice ? `,price:[1..${Math.max(1, Math.floor(retailPrice - 1))}],priceCurrency:USD` : "";
  const url = `https://api.ebay.com/buy/browse/v1/item_summary/search?q=${encodeURIComponent(query)}&filter=conditions:{USED}${priceFilter}&limit=5`;

  const res = await fetch(url, {
    headers: {
      Authorization: `Bearer ${token}`,
      "X-EBAY-C-MARKETPLACE-ID": "EBAY_US"
    }
  });
  if (!res.ok) return [];
  const data = await res.json();
  const items = data.itemSummaries || [];

  return items
    .map((item) => {
      const priceNum = parseFloat(item.price?.value || "0");
      if (!priceNum || (retailPrice && priceNum >= retailPrice)) return null;
      const image = item.thumbnailImages?.[0]?.imageUrl || item.image?.imageUrl;
      if (!image || !item.itemWebUrl) return null;
      const title = item.title || query;
      return {
        name: title.length > 52 ? title.slice(0, 49).trim() + "…" : title,
        price: `$${priceNum.toFixed(2)}`,
        priceNum,
        source: "eBay",
        labels: ["Condition", "Shipping", "Seller", "Source"],
        facts: [
          item.condition || "Pre-owned",
          item.shippingOptions?.[0]?.shippingCost?.value === "0.00" ? "Free" : "Check listing",
          item.seller?.username || "Verified",
          "eBay"
        ],
        why: `Pre-owned match for “${query}” on eBay.`,
        url: item.itemWebUrl,
        image
      };
    })
    .filter(Boolean)
    .slice(0, 3);
}

function isGenderCompatible(department, listingTitle) {
  const lower = String(listingTitle || "").toLowerCase();
  // Never recommend Kids/Baby/Toddler/Youth items unless the user is explicitly shopping Kids
  if (department !== "Kids" && /\b(kids?|toddler|baby|infant|youth|boys?|girls?|\d+t)\b/.test(lower)) {
    return false;
  }
  if (!department) return true;
  if (department === "Men" && /\b(women'?s|womens|woman'?s|ladies)\b/.test(lower)) return false;
  if (department === "Women" && /\b(men'?s|mens)\b/.test(lower)) return false;
  return true;
}

function toPoshmarkSize(selectedSize, department = "", garment = "") {
  if (!selectedSize) return "";
  const raw = String(selectedSize).toUpperCase().replace(/^(?:US|EU|EUR|UK)\s*/i, "").trim();
  const isShoe = /\b(shoe|shoes|sneaker|sneakers|boot|boots|loafer|heel|sandal|clog|mule)\b/i.test(garment);
  const num = parseFloat(raw);
  // Convert EU shoe sizes (35–46) to Poshmark US shoe sizes
  if (isShoe && Number.isFinite(num) && num >= 35 && num <= 46) {
    const us = department === "Men" ? Math.round((num - 33) * 2) / 2 : Math.round((num - 30.5) * 2) / 2;
    return String(us);
  }
  return raw;
}

async function searchPoshmark(query, retailPrice, department, color = "", page = 1, size = "") {
  const deptParam = department ? `&department=${encodeURIComponent(department)}` : "";
  const colorParam = color ? `&color=${encodeURIComponent(color)}` : "";
  const sizeParam = size ? `&size[]=${encodeURIComponent(size)}` : "";
  const pageParam = page > 1 ? `&page=${page}` : "";
  const url = `https://poshmark.com/search?query=${encodeURIComponent(query)}&type=listings${deptParam}${colorParam}${sizeParam}${pageParam}`;
  const res = await fetch(url, {
    headers: { Accept: "text/html,application/xhtml+xml", "Accept-Language": "en-US,en;q=0.9" }
  });
  if (!res.ok) return [];
  return parsePoshmarkTiles(await res.text(), query, retailPrice, department);
}

async function searchDepop(query, retailPrice, department) {
  try {
    const url = `https://www.depop.com/search/?q=${encodeURIComponent(query)}`;
    const res = await fetch(url, {
      headers: { Accept: "text/html,application/xhtml+xml", "Accept-Language": "en-US,en;q=0.9" },
      signal: AbortSignal.timeout(4500)
    });
    if (!res.ok) return [];
    const html = await res.text();
    const listings = [];
    const seen = new Set();
    const queryCatIdx = detectCategoryIndex(query);

    // Depop embeds product JSON in __NEXT_DATA__ or product links
    const nextMatch = html.match(/<script id="__NEXT_DATA__"[^>]*>([\s\S]*?)<\/script>/);
    if (nextMatch) {
      const data = JSON.parse(nextMatch[1]);
      const products =
        data?.props?.pageProps?.initialReduxState?.productSearch?.products ||
        data?.props?.pageProps?.products ||
        [];
      for (const p of Array.isArray(products) ? products : []) {
        const slug = p?.slug;
        const priceNum = parseFloat(p?.price?.priceAmount || p?.priceAmount || "0");
        const image = p?.preview?.["480"] || p?.preview?.["320"] || p?.pictures?.[0]?.["480"] || "";
        const title = decodeHtml(p?.description || p?.slug?.replace(/-/g, " ") || "").slice(0, 70);
        if (!slug || !priceNum || !image || !title) continue;
        if (retailPrice && priceNum >= retailPrice) continue;
        if (SPAM_LISTING_RE.test(title)) continue;
        if (!isCategoryCompatible(queryCatIdx, title)) continue;
        if (!isGenderCompatible(department, title)) continue;
        const itemUrl = `https://www.depop.com/products/${slug}/`;
        if (seen.has(itemUrl)) continue;
        seen.add(itemUrl);
        const size = p?.sizes?.[0] || extractSize("", title);
        listings.push({
          name: title.length > 52 ? title.slice(0, 49).trim() + "…" : title,
          price: `$${priceNum.toFixed(2)}`,
          priceNum,
          source: "Depop",
          labels: ["Listed size", "Condition", "Brand", "Source"],
          facts: [String(size || "See listing"), "Pre-owned", p?.brandName || "Secondhand", "Depop"],
          why: `Live secondhand match for “${query}” on Depop.`,
          url: itemUrl,
          image
        });
        if (listings.length >= 6) break;
      }
    }
    return listings;
  } catch {
    return [];
  }
}

async function searchGrailed(query, retailPrice, department) {
  try {
    const url = `https://www.grailed.com/shop?query=${encodeURIComponent(query)}`;
    const res = await fetch(url, {
      headers: { Accept: "text/html,application/xhtml+xml", "Accept-Language": "en-US,en;q=0.9" },
      signal: AbortSignal.timeout(4500)
    });
    if (!res.ok) return [];
    const html = await res.text();
    const listings = [];
    const seen = new Set();
    const queryCatIdx = detectCategoryIndex(query);

    const nextMatch = html.match(/<script id="__NEXT_DATA__"[^>]*>([\s\S]*?)<\/script>/);
    if (nextMatch) {
      const data = JSON.parse(nextMatch[1]);
      const hits =
        data?.props?.pageProps?.initialState?.search?.hits ||
        data?.props?.pageProps?.listings ||
        [];
      for (const h of Array.isArray(hits) ? hits : []) {
        const id = h?.id;
        const priceNum = parseFloat(h?.price || "0");
        const image = h?.cover_photo?.url || h?.photos?.[0]?.url || "";
        const title = decodeHtml(h?.title || "");
        if (!id || !priceNum || !image || !title) continue;
        if (retailPrice && priceNum >= retailPrice) continue;
        if (SPAM_LISTING_RE.test(title)) continue;
        if (!isCategoryCompatible(queryCatIdx, title)) continue;
        if (!isGenderCompatible(department, title)) continue;
        const itemUrl = `https://www.grailed.com/listings/${id}`;
        if (seen.has(itemUrl)) continue;
        seen.add(itemUrl);
        listings.push({
          name: title.length > 52 ? title.slice(0, 49).trim() + "…" : title,
          price: `$${priceNum.toFixed(2)}`,
          priceNum,
          source: "Grailed",
          labels: ["Listed size", "Condition", "Designer", "Source"],
          facts: [String(h?.size || "See listing").toUpperCase(), h?.condition || "Pre-owned", h?.designer_names || "Archive", "Grailed"],
          why: `Live archive match for “${query}” on Grailed.`,
          url: itemUrl,
          image
        });
        if (listings.length >= 6) break;
      }
    }
    return listings;
  } catch {
    return [];
  }
}

async function searchTheRealReal(query, retailPrice, department) {
  const path = department === "Men" ? "/products/men" : department === "Women" ? "/products/women" : "/products";
  const url = `https://www.therealreal.com${path}?keywords=${encodeURIComponent(query)}`;
  const res = await fetch(url, {
    headers: { Accept: "text/html,application/xhtml+xml", "Accept-Language": "en-US,en;q=0.9" }
  });
  if (!res.ok) return [];
  return parseTheRealRealTiles(await res.text(), query, retailPrice).filter((x) => isGenderCompatible(department, x.name));
}

function sizeMatchesSelected(listedSize, selectedSize) {
  if (!listedSize || !selectedSize || listedSize === "See listing") return false;
  const a = String(listedSize).toUpperCase().replace(/\s+/g, " ").trim();
  const b = String(selectedSize).toUpperCase().replace(/\s+/g, " ").trim();
  if (a === b || a.includes(b) || b.includes(a)) return true;
  // EU shoe size (35–46) to US women/men approximate match
  const euNum = parseFloat(b.replace(/^(EU|EUR)\s*/i, ""));
  const usNum = parseFloat(a.replace(/^US\s*/i, ""));
  if (euNum >= 35 && euNum <= 46 && usNum >= 4 && usNum <= 14) {
    const approxUsW = euNum - 30.5;
    const approxUsM = euNum - 32.5;
    if (Math.abs(usNum - approxUsW) <= 0.6 || Math.abs(usNum - approxUsM) <= 0.6) return true;
  }
  return false;
}

const COLOR_FAMILY_MAP = {
  black: "black", charcoal: "black", noir: "black", onyx: "black",
  white: "white", ivory: "white", cream: "white", ecru: "white", "off-white": "white",
  gray: "gray", grey: "gray", heather: "gray", slate: "gray", silver: "gray",
  brown: "brown", chocolate: "brown", espresso: "brown", taupe: "tan", camel: "tan", beige: "tan", khaki: "tan", sand: "tan", tan: "tan",
  navy: "blue", blue: "blue", indigo: "blue", cobalt: "blue", denim: "blue",
  green: "green", olive: "green", sage: "green", emerald: "green", forest: "green",
  pink: "pink", rose: "pink", blush: "pink", magenta: "pink",
  red: "red", burgundy: "red", maroon: "red", crimson: "red", wine: "red",
  purple: "purple", lavender: "purple", lilac: "purple", plum: "purple",
  orange: "orange", rust: "orange", terracotta: "orange",
  yellow: "yellow", mustard: "yellow", gold: "yellow"
};

function isColorCompatible(targetColor, listingTitle) {
  if (!targetColor) return true;
  const targetFam = COLOR_FAMILY_MAP[String(targetColor).toLowerCase()] || String(targetColor).toLowerCase();
  const titleLower = String(listingTitle || "").toLowerCase();
  const matches = titleLower.match(ALL_COLOR_WORDS_RE);
  if (!matches || matches.length === 0) return true;
  const listingFams = matches.map((m) => COLOR_FAMILY_MAP[m.toLowerCase()] || m.toLowerCase());
  // Allow close neutral/adjacent pairs (e.g. brown/tan, red/pink for magenta/burgundy)
  const compatible = new Set([targetFam]);
  if (targetFam === "brown" || targetFam === "tan") { compatible.add("brown"); compatible.add("tan"); }
  if (targetFam === "red" || targetFam === "pink") { compatible.add("red"); compatible.add("pink"); }
  return listingFams.some((f) => compatible.has(f));
}

function rgbToCanonicalColor(r, g, b) {
  const rn = r / 255, gn = g / 255, bn = b / 255;
  const max = Math.max(rn, gn, bn);
  const min = Math.min(rn, gn, bn);
  const d = max - min;
  const s = max === 0 ? 0 : d / max;
  const v = max;

  if (v < 0.22) return "Black";
  if (s < 0.14) {
    if (v > 0.82) return "White";
    return "Gray";
  }
  let h = 0;
  if (d > 0) {
    if (max === rn) h = ((gn - bn) / d) % 6;
    else if (max === gn) h = (bn - rn) / d + 2;
    else h = (rn - gn) / d + 4;
    h = Math.round(h * 60);
    if (h < 0) h += 360;
  }
  if (h < 15 || h >= 342) return v < 0.45 ? "Red" : "Red";
  if (h < 38) return v < 0.55 ? "Brown" : s < 0.45 ? "Tan" : "Orange";
  if (h < 68) return s < 0.38 ? "Tan" : "Yellow";
  if (h < 168) return "Green";
  if (h < 252) return "Blue";
  if (h < 298) return "Purple";
  return "Pink";
}

function isSkinTone(r, g, b) {
  return r > 95 && g > 40 && b > 20 && r > g && r > b && (r - Math.min(g, b)) > 15 && Math.abs(r - g) > 15 && g > b;
}

function cleanSellerDescription(raw, listingTitle = "") {
  if (!raw) return "";
  let text = decodeHtml(
    String(raw)
      .replace(/\\n|\\r|\\t/g, " ")
      .replace(/<[^>]+>/g, " ")
      .replace(/#[a-z0-9_]+/gi, "")
      .replace(/https?:\/\/\S+/g, "")
      .replace(/[\u{1F300}-\u{1FAFF}\u{2600}-\u{27BF}]/gu, "")
      .replace(/\b(?:PRELOVED|NWT|NWOT|EUC|GUC|VGUC|BNWT|FINAL SALE|PRICE FIRM|NO TRADES|SMOKE FREE|PET FREE)\b[!:\s-]*/gi, "")
      .replace(/[!]{2,}/g, ".")
      .replace(/\s+/g, " ")
      .trim()
  );

  // Reject Poshmark UI/tooltip boilerplate that is not an item description
  if (/\b(your new badge|about page|posh ambassador|making your status|sign up for poshmark|shop .+ closet)\b/i.test(text)) {
    return "";
  }

  // Split into sentences, drop promo/bundle spam and exact title repeats
  const titleNorm = String(listingTitle || "").toLowerCase().replace(/[^a-z0-9]+/g, " ").trim();
  const sentences = text
    .split(/(?<=[.!?])\s+/)
    .map((s) => s.trim())
    .filter((s) => {
      if (s.length < 14) return false;
      if (/\b(bundle|offer|shipping|closet|smoke.?free|pet.?free|questions|comment below|check out my|follow me|poshmark)\b/i.test(s)) return false;
      const sNorm = s.toLowerCase().replace(/[^a-z0-9]+/g, " ").trim();
      if (titleNorm && (sNorm === titleNorm || titleNorm.includes(sNorm))) return false;
      return true;
    });

  if (sentences.length === 0) return "";

  // Take 1-2 clean sentences up to ~155 chars
  let out = sentences[0];
  if (out.length < 90 && sentences[1] && (out.length + sentences[1].length + 1) <= 160) {
    out = `${out} ${sentences[1]}`;
  }
  if (out.length > 160) {
    out = out.slice(0, 157).replace(/\s+\S*$/, "").replace(/[,;:\-]+$/, "") + "…";
  }
  return out;
}

function extractPoshmarkDescription(html, listingTitle = "") {
  // 1. Prefer structured Product JSON-LD description
  const ldBlocks = html.matchAll(/<script[^>]+type="application\/ld\+json"[^>]*>([\s\S]*?)<\/script>/gi);
  for (const m of ldBlocks) {
    try {
      const data = JSON.parse(m[1]);
      const nodes = Array.isArray(data) ? data : [data];
      for (const n of nodes) {
        if (n?.["@type"] === "Product" && typeof n.description === "string") {
          const cleaned = cleanSellerDescription(n.description, listingTitle);
          if (cleaned) return cleaned;
        }
      }
    } catch {
      // Ignore malformed JSON-LD
    }
  }
  // 2. Fallback to the dedicated listing__description element (never arbitrary JSON keys)
  const divMatch = html.match(/class="[^"]*listing__description[^"]*"[^>]*>([\s\S]*?)<\/div>/i);
  if (divMatch) {
    const cleaned = cleanSellerDescription(divMatch[1], listingTitle);
    if (cleaned) return cleaned;
  }
  return "";
}

const trimmedImageCache = new Map();

function blobToDataUrl(blob) {
  return blob.arrayBuffer().then((buf) => {
    const bytes = new Uint8Array(buf);
    let binary = "";
    const chunk = 0x8000;
    for (let i = 0; i < bytes.length; i += chunk) {
      binary += String.fromCharCode(...bytes.subarray(i, i + chunk));
    }
    return `data:${blob.type || "image/jpeg"};base64,${btoa(binary)}`;
  });
}

async function trimImageBars(imageUrl) {
  if (!imageUrl || typeof OffscreenCanvas === "undefined" || typeof createImageBitmap === "undefined") {
    return imageUrl;
  }
  if (trimmedImageCache.has(imageUrl)) return trimmedImageCache.get(imageUrl);

  try {
    const res = await fetch(imageUrl, { signal: AbortSignal.timeout(3000) });
    if (!res.ok) return imageUrl;
    const blob = await res.blob();
    const bitmap = await createImageBitmap(blob);
    const origW = bitmap.width;
    const origH = bitmap.height;
    if (origW < 40 || origH < 40) {
      bitmap.close?.();
      return imageUrl;
    }

    // Analyze on a fast 128px-max canvas to detect solid-color letterbox/pillarbox bars of any color
    const scale = Math.min(1, 128 / Math.max(origW, origH));
    const aw = Math.max(16, Math.round(origW * scale));
    const ah = Math.max(16, Math.round(origH * scale));
    const aCanvas = new OffscreenCanvas(aw, ah);
    const aCtx = aCanvas.getContext("2d", { willReadFrequently: true });
    aCtx.drawImage(bitmap, 0, 0, aw, ah);
    const { data } = aCtx.getImageData(0, 0, aw, ah);

    const isUniformLine = (isRow, idx) => {
      const len = isRow ? aw : ah;
      const mid = Math.floor(len / 2);
      const anchorOffset = isRow ? (idx * aw + mid) * 4 : (mid * aw + idx) * 4;
      const ar = data[anchorOffset];
      const ag = data[anchorOffset + 1];
      const ab = data[anchorOffset + 2];
      let match = 0;
      for (let i = 0; i < len; i++) {
        const off = isRow ? (idx * aw + i) * 4 : (i * aw + idx) * 4;
        const dr = data[off] - ar;
        const dg = data[off + 1] - ag;
        const db = data[off + 2] - ab;
        if (dr * dr + dg * dg + db * db <= 280) match += 1;
      }
      return match / len >= 0.94;
    };

    const maxTrimX = Math.floor(aw * 0.38);
    const maxTrimY = Math.floor(ah * 0.38);
    let left = 0, right = aw - 1, top = 0, bottom = ah - 1;

    while (left < maxTrimX && isUniformLine(false, left)) left++;
    while (right > aw - 1 - maxTrimX && isUniformLine(false, right)) right--;
    while (top < maxTrimY && isUniformLine(true, top)) top++;
    while (bottom > ah - 1 - maxTrimY && isUniformLine(true, bottom)) bottom--;

    const trimFracX = (left + (aw - 1 - right)) / aw;
    const trimFracY = (top + (ah - 1 - bottom)) / ah;

    // Only re-encode if we actually found bars (>= 2.5% on any axis) and enough content remains
    const innerW = right - left + 1;
    const innerH = bottom - top + 1;
    if ((trimFracX < 0.025 && trimFracY < 0.025) || innerW < aw * 0.35 || innerH < ah * 0.35) {
      bitmap.close?.();
      if (trimmedImageCache.size > 160) trimmedImageCache.clear();
      trimmedImageCache.set(imageUrl, imageUrl);
      return imageUrl;
    }

    // Shave 1 analysis pixel inward on trimmed edges to remove JPEG ringing along the bar seam
    const padL = left > 0 ? 1 : 0;
    const padR = right < aw - 1 ? 1 : 0;
    const padT = top > 0 ? 1 : 0;
    const padB = bottom < ah - 1 ? 1 : 0;

    const sx = Math.min(origW - 2, Math.round(((left + padL) / aw) * origW));
    const sy = Math.min(origH - 2, Math.round(((top + padT) / ah) * origH));
    const sw = Math.max(16, Math.round(((innerW - padL - padR) / aw) * origW));
    const sh = Math.max(16, Math.round(((innerH - padT - padB) / ah) * origH));

    const outScale = Math.min(1, 640 / Math.max(sw, sh));
    const outW = Math.max(16, Math.round(sw * outScale));
    const outH = Math.max(16, Math.round(sh * outScale));
    const outCanvas = new OffscreenCanvas(outW, outH);
    const outCtx = outCanvas.getContext("2d");
    outCtx.drawImage(bitmap, sx, sy, sw, sh, 0, 0, outW, outH);
    bitmap.close?.();

    const outBlob = await outCanvas.convertToBlob({ type: "image/jpeg", quality: 0.88 });
    const dataUrl = await blobToDataUrl(outBlob);
    if (trimmedImageCache.size > 160) trimmedImageCache.clear();
    trimmedImageCache.set(imageUrl, dataUrl);
    return dataUrl;
  } catch {
    return imageUrl;
  }
}

const visualSigCache = new Map();

async function extractVisualSignature(imageUrl, catIdx = -1) {
  if (!imageUrl || typeof OffscreenCanvas === "undefined" || typeof createImageBitmap === "undefined") {
    return null;
  }
  const cacheKey = `${imageUrl}::${catIdx}`;
  if (visualSigCache.has(cacheKey)) return visualSigCache.get(cacheKey);

  try {
    const res = await fetch(imageUrl, { signal: AbortSignal.timeout(2500) });
    if (!res.ok) return null;
    const blob = await res.blob();
    const bitmap = await createImageBitmap(blob);

    // Garment-aware ROI cropping so full-body model photos focus on the actual garment
    const sw = bitmap.width;
    const sh = bitmap.height;
    let rx = 0.16, ry = 0.14, rw = 0.68, rh = 0.72;
    if (catIdx === 0 || catIdx === 1 || catIdx === 5) {
      // Jackets, sweaters, tops -> upper-center torso
      rx = 0.24; ry = 0.18; rw = 0.52; rh = 0.38;
    } else if (catIdx === 2 || catIdx === 4) {
      // Pants, jeans, skirts -> lower-center
      rx = 0.24; ry = 0.46; rw = 0.52; rh = 0.42;
    }

    const sx = Math.round(sw * rx);
    const sy = Math.round(sh * ry);
    const cw = Math.max(1, Math.round(sw * rw));
    const ch = Math.max(1, Math.round(sh * rh));

    const size = 24;
    const canvas = new OffscreenCanvas(size, size);
    const ctx = canvas.getContext("2d", { willReadFrequently: true });
    ctx.drawImage(bitmap, sx, sy, cw, ch, 0, 0, size, size);
    bitmap.close?.();

    const { data } = ctx.getImageData(0, 0, size, size);
    const hist = new Float32Array(64);
    const luma = new Float32Array(64);
    const colorVotes = new Map();
    let fgCount = 0;

    // Sample corner pixels of the ROI to detect the exact studio background color (white, off-white, light gray)
    const corners = [0, (size - 1) * 4, ((size - 1) * size) * 4, (size * size - 1) * 4];
    let bgR = 0, bgG = 0, bgB = 0;
    for (const c of corners) {
      bgR += data[c];
      bgG += data[c + 1];
      bgB += data[c + 2];
    }
    bgR /= 4; bgG /= 4; bgB /= 4;

    for (let y = 0; y < size; y++) {
      for (let x = 0; x < size; x++) {
        const idx = (y * size + x) * 4;
        const r = data[idx];
        const g = data[idx + 1];
        const b = data[idx + 2];
        const a = data[idx + 3];
        if (a < 128) continue;

        const maxC = Math.max(r, g, b);
        const minC = Math.min(r, g, b);
        const sat = maxC - minC;
        const lum = 0.299 * r + 0.587 * g + 0.114 * b;

        const gx = Math.floor((x / size) * 8);
        const gy = Math.floor((y / size) * 8);
        luma[gy * 8 + gx] += lum;

        // Ignore studio background (near-white/light-gray OR matching the sampled corner background) and skin tones
        const bgDistSq = (r - bgR) ** 2 + (g - bgG) ** 2 + (b - bgB) ** 2;
        const isStudioBg = (lum > 205 && sat < 24) || (bgDistSq < 784 && sat < 28);
        if (!isStudioBg && !isSkinTone(r, g, b)) {
          const bin = ((r >> 6) << 4) | ((g >> 6) << 2) | (b >> 6);
          hist[bin] += 1;
          fgCount += 1;
          const cname = rgbToCanonicalColor(r, g, b);
          // Weight saturated garment colors higher than neutral White/Gray studio shadows
          const weight = (cname === "Gray" || cname === "White") ? 0.35 : 1;
          colorVotes.set(cname, (colorVotes.get(cname) || 0) + weight);
        }
      }
    }

    if (fgCount > 0) {
      for (let i = 0; i < 64; i++) hist[i] /= fgCount;
    }
    let dominantColor = "";
    let bestVote = 0;
    for (const [cname, v] of colorVotes.entries()) {
      if (v > bestVote) {
        bestVote = v;
        dominantColor = cname;
      }
    }
    if (bestVote < 18) dominantColor = "";

    let lumaMean = 0;
    for (let i = 0; i < 64; i++) {
      luma[i] /= 9;
      lumaMean += luma[i];
    }
    lumaMean /= 64;

    // 64-bit perceptual dHash (horizontal neighbor differences on 8x8 luminance grid) for duplicate detection
    let dhashHi = 0;
    let dhashLo = 0;
    for (let y = 0; y < 8; y++) {
      for (let x = 0; x < 8; x++) {
        const cur = luma[y * 8 + x];
        const nxt = luma[y * 8 + ((x + 1) % 8)];
        const bit = cur > nxt ? 1 : 0;
        const pos = y * 8 + x;
        if (pos < 32) dhashLo = (dhashLo << 1) | bit;
        else dhashHi = (dhashHi << 1) | bit;
      }
    }

    // Sobel-style edge/texture density on 8x8 luminance grid (solid vs patterned/textured garment)
    let edgeSum = 0;
    let edgeCount = 0;
    for (let y = 1; y < 7; y++) {
      for (let x = 1; x < 7; x++) {
        const gx = Math.abs(luma[y * 8 + (x + 1)] - luma[y * 8 + (x - 1)]);
        const gy = Math.abs(luma[(y + 1) * 8 + x] - luma[(y - 1) * 8 + x]);
        edgeSum += Math.min(255, gx + gy);
        edgeCount += 1;
      }
    }
    const edgeDensity = Math.min(1, edgeSum / (edgeCount * 110));

    let lumaNorm = 0;
    for (let i = 0; i < 64; i++) {
      luma[i] -= lumaMean;
      lumaNorm += luma[i] * luma[i];
    }
    lumaNorm = Math.sqrt(lumaNorm) || 1;
    for (let i = 0; i < 64; i++) luma[i] /= lumaNorm;

    const sig = {
      hist,
      luma,
      hasFg: fgCount > 12,
      dominantColor,
      dhashHi,
      dhashLo,
      edgeDensity,
      aspectRatio: cw / Math.max(1, ch)
    };
    if (visualSigCache.size > 160) visualSigCache.clear();
    visualSigCache.set(cacheKey, sig);
    return sig;
  } catch {
    return null;
  }
}

function popcount32(x) {
  let n = x >>> 0;
  let c = 0;
  while (n) {
    n &= n - 1;
    c += 1;
  }
  return c;
}

function dhashDistance(a, b) {
  if (!a || !b) return 64;
  return popcount32(a.dhashHi ^ b.dhashHi) + popcount32(a.dhashLo ^ b.dhashLo);
}

function compareVisualSignatures(a, b) {
  if (!a || !b) return null;
  let colorSim = 0;
  if (a.hasFg && b.hasFg) {
    for (let i = 0; i < 64; i++) {
      colorSim += Math.min(a.hist[i], b.hist[i]);
    }
  }
  let dot = 0;
  for (let i = 0; i < 64; i++) dot += a.luma[i] * b.luma[i];
  const structSim = (dot + 1) / 2;
  // Pattern/texture similarity (1 = same texture density, 0 = solid vs very busy pattern)
  const textureSim = 1 - Math.min(1, Math.abs((a.edgeDensity || 0) - (b.edgeDensity || 0)) * 1.4);

  return a.hasFg && b.hasFg
    ? { combined: 0.55 * colorSim + 0.25 * structSim + 0.2 * textureSim, colorSim, structSim, textureSim }
    : { combined: 0.65 * structSim + 0.35 * textureSim, colorSim: null, structSim, textureSim };
}

function scoreRelevance(listing, rawTitle, brand, color = "", selectedSize = "", contextText = "") {
  const targetWords = String(rawTitle || "")
    .toLowerCase()
    .replace(/[^a-z0-9\s]/g, " ")
    .split(/\s+/)
    .filter((w) => w.length > 2);
  const titleLower = String(listing.name || "").toLowerCase();
  let score = 0;

  for (const w of targetWords) {
    if (titleLower.includes(w)) score += 3;
  }
  const garment = findGarmentWord(rawTitle) || findGarmentWord(contextText);
  if (garment && new RegExp(`\\b${garment}s?\\b`, "i").test(titleLower)) {
    score += 6;
  }
  // Heavily reward matching defining silhouette/style keywords (e.g. "tabi", "chelsea", "trench", "corset")
  const styleHits = extractStyleKeywords(`${rawTitle} ${contextText}`);
  for (const kw of styleHits) {
    if (new RegExp(`\\b${kw.replace(/[- ]/g, "[-\\s]?")}\\b`, "i").test(titleLower)) {
      score += 10;
    }
  }
  if (brand && titleLower.includes(brand.toLowerCase())) {
    score += 4;
  }
  if (color) {
    const targetColor = color.toLowerCase();
    if (titleLower.includes(targetColor)) {
      score += 6;
    } else {
      // Penalize listings that explicitly name a conflicting color (e.g. "White" when shopping for "Red"/"Pink")
      const mentionedColors = titleLower.match(ALL_COLOR_WORDS_RE) || [];
      if (mentionedColors.length > 0 && !mentionedColors.some((c) => c.toLowerCase() === targetColor)) {
        score -= 14;
      }
    }
  }
  const listedSize = listing.facts?.[0] || "";
  if (selectedSize) {
    if (sizeMatchesSelected(listedSize, selectedSize)) {
      score += 22;
    } else if (listedSize && listedSize !== "See listing") {
      score -= 10;
    }
  }
  return score;
}

async function searchAllMarketplaces(
  rawTitle,
  brand,
  retailPrice,
  department = "",
  color = "",
  excludeUrls = [],
  attempt = 0,
  selectedSize = "",
  productImage = "",
  contextText = ""
) {
  const query = buildCleanQuery(rawTitle, brand, color, contextText);
  const garment = findGarmentWord(rawTitle) || findGarmentWord(contextText);
  const titleCatIdx = detectCategoryIndex(rawTitle);
  const queryCatIdx = titleCatIdx >= 0 ? titleCatIdx : detectCategoryIndex(contextText);

  // Never search with an empty or meaningless query (e.g. "LOOK" on an outfit page)
  const queryTokens = query.split(/\s+/).filter(Boolean);
  if (!query || (!garment && queryTokens.length < 2)) {
    return { query: "", listings: [] };
  }

  // Analyze the retail product photo up front so we can infer dominant garment color on ANY site
  const retailSig = productImage ? await extractVisualSignature(productImage, queryCatIdx) : null;
  if (!color && retailSig?.dominantColor) {
    color = retailSig.dominantColor;
  }

  const excludeSet = new Set(Array.isArray(excludeUrls) ? excludeUrls : []);
  const cacheKey = `${query.toLowerCase()}::${department}::${color}::${selectedSize}::${retailPrice || 0}::${attempt}`;
  if (attempt === 0 && excludeSet.size === 0 && searchCache.has(cacheKey)) {
    return searchCache.get(cacheKey);
  }

  const styleHits = extractStyleKeywords(`${rawTitle} ${contextText}`);
  const primaryStyle = styleHits[0] || "";
  const colorQuery = color && !query.toLowerCase().includes(color.toLowerCase()) ? `${color} ${query}` : query;
  const poshSize = toPoshmarkSize(selectedSize, department, garment);

  // Progressive refinement strategy:
  // Attempt 0: balanced [color + top descriptors + garment]
  // Attempt 1: tighter exact-match [brand + color + descriptors + garment] (falls back to unseen pool)
  // Attempt 2: style-twin angle [color + alternate descriptors + garment] on page 2
  // Attempt 3+: deeper catalog pages so every reload surfaces fresh unseen listings
  let activeQuery = colorQuery;
  let poshPage = 1;

  if (attempt === 1) {
    if (brand && !colorQuery.toLowerCase().includes(brand.toLowerCase())) {
      activeQuery = `${brand} ${colorQuery}`.trim();
    } else {
      poshPage = 2;
    }
  } else if (attempt >= 2) {
    poshPage = attempt;
    const words = query.split(/\s+/).filter((w) => w.toLowerCase() !== garment);
    const altWord = words.length > 1 ? words[words.length - 1] : words[0] || "";
    activeQuery = [color, altWord, garment].filter(Boolean).join(" ").trim() || colorQuery;
  }

  const [posh, trr, ebayImg, ebay, depop, grailed] = await Promise.all([
    searchPoshmark(activeQuery, retailPrice, department, color, poshPage, poshSize).catch(() => []),
    attempt <= 1 ? searchTheRealReal(activeQuery, retailPrice, department).catch(() => []) : Promise.resolve([]),
    attempt === 0 && productImage ? searchEbayByImage(productImage, retailPrice, activeQuery, department, color).catch(() => []) : Promise.resolve([]),
    attempt === 0 ? searchEbay([department, activeQuery].filter(Boolean).join(" "), retailPrice).catch(() => []) : Promise.resolve([]),
    attempt === 0 ? searchDepop(activeQuery, retailPrice, department).catch(() => []) : Promise.resolve([]),
    attempt === 0 ? searchGrailed(activeQuery, retailPrice, department).catch(() => []) : Promise.resolve([])
  ]);

  let all = [...ebayImg, ...ebay, ...posh, ...trr, ...depop, ...grailed].filter((item) => !excludeSet.has(item.url));

  // If fewer than 3 unseen matches in the exact size, top up without the size filter
  if (all.length < 3 && poshSize) {
    const anySizeExtra = await searchPoshmark(activeQuery, retailPrice, department, color, poshPage, "").catch(() => []);
    const seen = new Set([...excludeSet, ...all.map((x) => x.url)]);
    for (const item of anySizeExtra) {
      if (!seen.has(item.url)) {
        seen.add(item.url);
        all.push(item);
      }
    }
  }

  // If fewer than 3 unseen matches, top up from the base query / next page so we always return 3 fresh items
  if (all.length < 3) {
    const fallbackQuery = attempt >= 1 ? colorQuery : (garment ? `${query.split(" ")[0]} ${garment}`.trim() : query.split(" ").slice(0, 2).join(" "));
    const extra = await searchPoshmark(fallbackQuery || query, retailPrice, department, color, attempt >= 1 ? poshPage + 1 : 1).catch(() => []);
    const seen = new Set([...excludeSet, ...all.map((x) => x.url)]);
    for (const item of extra) {
      if (!seen.has(item.url)) {
        seen.add(item.url);
        all.push(item);
      }
    }
  }

  // Style-anchored safety net: keep primary defining style (e.g. "tabi") anchored before broadening to generic garment
  if (all.length < 3 && primaryStyle && garment) {
    const styleExtra = await searchPoshmark([color, primaryStyle, garment].filter(Boolean).join(" "), retailPrice, department, color, 1).catch(() => []);
    const seen = new Set([...excludeSet, ...all.map((x) => x.url)]);
    for (const item of styleExtra) {
      if (!seen.has(item.url)) {
        seen.add(item.url);
        all.push(item);
      }
    }
  }

  // Final safety net: if still < 3 (e.g. very rare style/color), broaden to [color + garment]
  if (all.length < 3 && garment) {
    const broadExtra = await searchPoshmark([color, garment].filter(Boolean).join(" "), retailPrice, department, color, 1).catch(() => []);
    const seen = new Set([...excludeSet, ...all.map((x) => x.url)]);
    for (const item of broadExtra) {
      if (!seen.has(item.url)) {
        seen.add(item.url);
        all.push(item);
      }
    }
  }

  all = all
    .filter((item) => isCategoryCompatible(queryCatIdx, item.name) && isColorCompatible(color, item.name))
    .map((item) => ({
      ...item,
      _score: scoreRelevance(item, rawTitle, brand, color, selectedSize, contextText)
    }));

  // 100% local, zero-tracking visual re-ranking (offscreen 176-dim HSV+HOG embedder + service-worker fallback)
  if (retailSig && all.length > 0) {
    all.sort((a, b) => (b._score - a._score) || ((a.priceNum || 9999) - (b.priceNum || 9999)));
    const topCandidates = all.slice(0, 12);
    const [candSigs, embedScores] = await Promise.all([
      Promise.all(topCandidates.map((item) => extractVisualSignature(item.image, -1))),
      productImage
        ? scoreWithOffscreenEmbedder(productImage, topCandidates.map((x) => x.image), queryCatIdx)
        : Promise.resolve(null)
    ]);

    topCandidates.forEach((item, idx) => {
      item._sig = candSigs[idx] || null;
      if (item._visualSearchBoost) item._score += item._visualSearchBoost;
      const emb = embedScores?.[idx];
      const cmp = compareVisualSignatures(retailSig, candSigs[idx]);
      if (emb) {
        const sim = emb.combined;
        if (emb.colorSim < 0.2) {
          item._score -= 14;
        } else {
          item._score += sim >= 0.42 ? (sim - 0.42) * 38 : (sim - 0.42) * 16;
        }
        item._visualSim = Math.round(sim * 100);
      } else if (cmp !== null) {
        const sim = cmp.combined;
        if (cmp.colorSim !== null && cmp.colorSim < 0.22) {
          item._score -= 14;
        } else {
          const visualDelta = sim >= 0.45 ? (sim - 0.45) * 34 : (sim - 0.45) * 16;
          item._score += visualDelta;
        }
        item._visualSim = Math.round(sim * 100);
      }
    });
    all = topCandidates;
  }

  // Enforce a minimum relevance floor so we never surface unrelated items
  const minScore = garment ? 8 : 6;
  const qualified = all.filter((item) => item._score >= minScore);

  // Rank by highest combined (text + visual) relevance first, then lowest price as tie-breaker
  qualified.sort((a, b) => (b._score - a._score) || ((a.priceNum || 9999) - (b.priceNum || 9999)));

  // Perceptual dHash deduplication: drop cross-posted listings that use the exact same photo
  const deduped = [];
  for (const item of qualified) {
    if (item._sig && deduped.some((kept) => kept._sig && dhashDistance(kept._sig, item._sig) <= 7)) {
      continue;
    }
    deduped.push(item);
    if (deduped.length >= 3) break;
  }

  const top3 = deduped.map(({ _sig, ...rest }) => rest);
  // Trim baked-in letterbox/pillarbox bars of any solid color from the final 3 thumbnails
  await Promise.all(
    top3.map(async (item) => {
      if (item.image) item.image = await trimImageBars(item.image);
    })
  );
  const result = { query: activeQuery, listings: top3 };
  if (attempt === 0 && excludeSet.size === 0 && result.listings.length > 0) {
    searchCache.set(cacheKey, result);
  }
  return result;
}

async function ensureOffscreenEmbedder() {
  if (!chrome.offscreen?.createDocument) return false;
  try {
    const existing = await chrome.offscreen.hasDocument?.();
    if (existing) return true;
    await chrome.offscreen.createDocument({
      url: "src/offscreen.html",
      reasons: ["DOM_SCRAPING"],
      justification: "On-device visual embedding (HSV + HOG) for local secondhand image matching."
    });
    return true;
  } catch {
    return false;
  }
}

let offscreenIdleTimer = null;

function scheduleOffscreenClose() {
  if (offscreenIdleTimer) clearTimeout(offscreenIdleTimer);
  offscreenIdleTimer = setTimeout(async () => {
    try {
      const hasDoc = await chrome.offscreen?.hasDocument?.();
      if (hasDoc) await chrome.offscreen.closeDocument();
    } catch {
      // Ignore
    }
  }, 25000);
}

async function scoreWithOffscreenEmbedder(retailImage, candidateImages, catIdx = -1) {
  const ready = await ensureOffscreenEmbedder();
  if (!ready) return null;
  scheduleOffscreenClose();
  return new Promise((resolve) => {
    chrome.runtime.sendMessage(
      { type: "CIRKULAR_OFFSCREEN_EMBED", retailImage, candidateImages: candidateImages.slice(0, 6), catIdx },
      (res) => {
        scheduleOffscreenClose();
        if (chrome.runtime.lastError || !res?.ok) {
          resolve(null);
          return;
        }
        resolve(res.scores || null);
      }
    );
  });
}

// Local-only price-drop & availability watcher for saved secondhand items (zero external servers)
const PRICE_WATCH_ALARM = "cirkular-price-watch";

async function checkSavedPrices() {
  try {
    const { savedItems = [] } = await chrome.storage.local.get({ savedItems: [] });
    if (!savedItems.length) return;
    let drops = 0;
    let changed = false;

    for (const item of savedItems.slice(0, 12)) {
      if (!item?.url || !/^https:\/\/(www\.)?(poshmark|therealreal|depop|grailed)\.com\//i.test(item.url)) continue;
      try {
        const res = await fetch(item.url, {
          headers: { Accept: "text/html" },
          signal: AbortSignal.timeout(5000)
        });
        if (!res.ok) continue;
        const html = await res.text();
        const isSold = /\b(sold out|this listing has been sold|item sold)\b/i.test(html.slice(0, 25000));
        const priceMatch = html.match(/"price"\s*:\s*"?([0-9]+(?:\.[0-9]{1,2})?)"?/i);
        const livePrice = priceMatch ? parseFloat(priceMatch[1]) : null;
        const savedPrice = parseFloat(String(item.price || "").replace(/[^0-9.]/g, ""));

        if (isSold && !item.sold) {
          item.sold = true;
          changed = true;
        }
        if (livePrice && savedPrice && livePrice < savedPrice - 0.5) {
          item.priceDrop = Number((savedPrice - livePrice).toFixed(2));
          item.price = `$${livePrice.toFixed(2)}`;
          drops += 1;
          changed = true;
        }
      } catch {
        // Ignore transient network errors
      }
    }

    if (changed) {
      await chrome.storage.local.set({ savedItems });
    }
    if (drops > 0) {
      chrome.action.setBadgeText({ text: String(drops) });
      chrome.action.setBadgeBackgroundColor({ color: "#b7ff3c" });
    }
  } catch {
    // Ignore
  }
}

chrome.runtime.onInstalled.addListener((details) => {
  chrome.alarms?.create(PRICE_WATCH_ALARM, { periodInMinutes: 360 });
  if (details.reason === "install") {
    chrome.tabs.create({ url: chrome.runtime.getURL("src/onboarding.html") });
  }
});

chrome.alarms?.onAlarm.addListener((alarm) => {
  if (alarm?.name === PRICE_WATCH_ALARM) {
    checkSavedPrices();
  }
});

chrome.action.onClicked.addListener((tab) => {
  if (!tab?.id) return;
  chrome.tabs.sendMessage(tab.id, { type: "CIRKULAR_TOGGLE_TRACKER" }, () => {
    void chrome.runtime.lastError;
  });
});

chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (msg?.type === "CIRKULAR_OPEN_ONBOARDING") {
    chrome.tabs.create({ url: chrome.runtime.getURL("src/onboarding.html") });
    sendResponse({ ok: true });
    return false;
  }
  if (msg?.type === "CIRKULAR_SEARCH") {
    searchAllMarketplaces(
      msg.title,
      msg.brand,
      msg.retailPrice,
      msg.department,
      msg.color,
      msg.excludeUrls || [],
      msg.attempt || 0,
      msg.selectedSize || "",
      msg.productImage || "",
      msg.contextText || ""
    )
      .then((data) => sendResponse({ ok: true, ...data }))
      .catch((err) => sendResponse({ ok: false, error: err.message, listings: [] }));
    return true;
  }
  if (msg?.type === "CIRKULAR_FETCH_PHOTOS") {
    (async () => {
      const url = String(msg.url || "");
      const pmMatch = url.match(/poshmark\.com\/listing\/[^?#]*?([a-f0-9]{24})(?:[/?#]|$)/i);
      if (!pmMatch) return { ok: true, images: [] };
      const listingId = pmMatch[1];
      const res = await fetch(`https://poshmark.com/listing/${listingId}`, {
        headers: { Accept: "text/html" },
        signal: AbortSignal.timeout(8000)
      });
      if (!res.ok) return { ok: false, images: [] };
      const html = await res.text();
      const images = new Map();
      const renditions = /https:\/\/di2ponv0v5otw\.cloudfront\.net\/posts\/\d{4}\/\d{2}\/\d{2}\/([a-f0-9]{24})\/([lsm])_(?:wp_)?([a-f0-9]{24})\.(?:jpe?g|webp)\b/g;
      const quality = { s: 0, m: 1, l: 2 };
      for (const [imgUrl, post, size, photo] of html.matchAll(renditions)) {
        if (post !== listingId) continue;
        const rank = quality[size];
        if (!images.has(photo) || images.get(photo).rank < rank) {
          images.set(photo, { url: imgUrl, rank });
        }
      }
      const rawImages = Array.from(images.values(), (x) => x.url).slice(0, 6);
      const cleanImages = await Promise.all(rawImages.map((u) => trimImageBars(u)));
      const description = extractPoshmarkDescription(html, msg.title || "");
      const sizeMatch =
        html.match(/"size"\s*:\s*"([^"]{1,16})"/i) ||
        html.match(/Size:\s*<[^>]*>\s*([^<\n]{1,16})/i);
      const size = sizeMatch ? decodeHtml(sizeMatch[1]).toUpperCase() : "";

      return { ok: true, images: cleanImages, description, size };
    })()
      .then((out) => sendResponse(out))
      .catch(() => sendResponse({ ok: false, images: [] }));
    return true;
  }
});
