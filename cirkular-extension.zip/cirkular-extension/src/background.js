const searchCache = new Map();
let ebayTokenCache = { token: null, expiresAt: 0 };

function decodeHtml(str) {
  return String(str || "")
    .replace(/&amp;/g, "&")
    .replace(/&quot;/g, '"')
    .replace(/&#39;|&apos;/g, "'")
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">")
    .replace(/\s+/g, " ")
    .trim();
}

const CATEGORY_GROUPS = [
  ["jacket", "coat", "blazer", "bomber", "parka", "trench", "windbreaker", "puffer", "anorak", "vest"],
  ["sweater", "cardigan", "knit", "hoodie", "sweatshirt", "pullover", "fleece", "jumper"],
  ["jeans", "denim", "pants", "trousers", "chinos", "joggers", "leggings", "shorts"],
  ["dress", "gown", "midi", "maxi", "mini dress", "romper", "jumpsuit"],
  ["skirt", "miniskirt"],
  ["shirt", "tee", "t-shirt", "top", "blouse", "tank", "polo", "camisole", "bodysuit"],
  ["shoe", "shoes", "sneaker", "sneakers", "boot", "boots", "loafer", "heel", "sandal", "clog", "mule"],
  ["bag", "tote", "purse", "backpack", "crossbody", "clutch", "wallet"],
  ["hat", "cap", "beanie", "beret", "bucket hat", "scarf", "gloves", "belt", "sunglasses"]
];

function detectCategoryIndex(text) {
  const lower = String(text || "").toLowerCase();
  for (let i = 0; i < CATEGORY_GROUPS.length; i++) {
    if (CATEGORY_GROUPS[i].some((kw) => new RegExp(`\\b${kw}s?\\b`, "i").test(lower))) {
      return i;
    }
  }
  return -1;
}

function isCategoryCompatible(queryCatIdx, listingTitle) {
  if (queryCatIdx < 0) return true;
  const listingCatIdx = detectCategoryIndex(listingTitle);
  // Reject if the listing clearly belongs to a different garment category (e.g. hat when shopping for jacket)
  if (listingCatIdx >= 0 && listingCatIdx !== queryCatIdx) return false;
  return true;
}

const SPAM_LISTING_RE = /\b(black friday|cyber monday|closet sale|% off|do not buy|not for sale|iso\b|in search of|bundle|promo|giveaway|live show|host pick)\b/i;

function findGarmentWord(text) {
  const lower = String(text || "").toLowerCase();
  for (const group of CATEGORY_GROUPS) {
    for (const kw of group) {
      if (new RegExp(`\\b${kw}s?\\b`, "i").test(lower)) return kw;
    }
  }
  return "";
}

const STYLE_KEYWORDS = [
  "tabi", "split-toe", "split toe", "chelsea", "combat", "western", "cowboy", "motorcycle", "moto",
  "ankle", "knee-high", "knee high", "thigh-high", "platform", "wedge", "stiletto", "kitten", "chunky",
  "mary jane", "ballet", "slingback", "penny", "oxford", "derby", "brogue", "espadrille",
  "cargo", "carpenter", "parachute", "pleated", "wide-leg", "wide leg", "flared", "bootcut", "straight", "baggy", "skinny",
  "cropped", "oversized", "fitted", "boxy", "relaxed", "tailored", "structured", "draped", "wrap", "corset", "peplum",
  "halter", "backless", "off-shoulder", "strapless", "one-shoulder", "turtleneck", "mock-neck", "mock neck", "v-neck", "crewneck", "bow",
  "trench", "puffer", "bomber", "biker", "varsity", "quilted", "shearling", "peacoat", "double-breasted",
  "leather", "suede", "denim", "linen", "silk", "satin", "velvet", "corduroy", "tweed", "cashmere", "wool", "mohair", "mesh", "lace", "chiffon", "organza", "ribbed", "crochet", "knit", "sequin",
  "floral", "striped", "plaid", "checkered", "gingham", "polka", "paisley", "printed", "embroidered"
];

function extractStyleKeywords(text) {
  const lower = String(text || "").toLowerCase();
  const found = [];
  for (const kw of STYLE_KEYWORDS) {
    if (new RegExp(`\\b${kw.replace(/[- ]/g, "[-\\s]?")}\\b`, "i").test(lower)) {
      found.push(kw);
    }
  }
  return found;
}

const ALL_COLOR_WORDS_RE = /\b(black|charcoal|noir|onyx|white|ivory|cream|ecru|off-white|gray|grey|heather|slate|brown|taupe|chocolate|espresso|camel|beige|khaki|sand|navy|blue|indigo|cobalt|green|olive|sage|emerald|forest|pink|rose|blush|magenta|red|burgundy|maroon|crimson|wine|purple|lavender|lilac|plum|orange|rust|terracotta|yellow|mustard|gold|silver)\b/gi;

function buildCleanQuery(rawTitle, brand, overrideColor = "") {
  const stopWords = /\b(new|with|tags|nwt|nwot|free|shipping|sale|off|limited|edition|official|store|shop|online|men's|women's|mens|womens|selected|items|display|army|genuine|real|pure|100%|vegan|faux|full-grain|top-grain|cm|mm|inch|inches|heel|heels)\b/gi;
  const garment = findGarmentWord(rawTitle);

  let q = String(rawTitle || "");
  // Strip store/brand name from generic query so indie brands don't crowd out style keywords
  if (brand && brand.length > 1) {
    const escapedBrand = brand.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
    q = q.replace(new RegExp(`\\b${escapedBrand}\\b`, "gi"), " ");
  }
  // If a live color swatch is selected, strip any stale color words from the product title
  if (overrideColor) {
    q = q.replace(ALL_COLOR_WORDS_RE, " ");
  }
  // Normalize animal-hide prefixes ("cow leather" -> "leather", "calfskin" -> "leather") so "cow" never triggers cow-print
  q = q
    .replace(/\b(cow|calf|lamb|goat|sheep|pig|bull|steer|horse)\s+(leather|suede|hide|skin)\b/gi, "$2")
    .replace(/\b(calfskin|lambskin|cowhide|sheepskin|goatskin)\b/gi, "leather")
    .replace(/\b\d+(?:\.\d+)?\s*(?:cm|mm|in|inch|inches|")\b/gi, " ")
    .replace(/[|–—•·/\\()[\]]/g, " ")
    .replace(stopWords, " ");

  const styleHits = extractStyleKeywords(q);
  const words = q
    .trim()
    .split(/\s+/)
    .filter((w) => w.length > 1 && w.toLowerCase() !== garment && !/^\d+$/.test(w));

  // Build prioritized query: signature style keywords first (e.g. "tabi", "leather"), then remaining descriptive words, then garment
  const core = [];
  const added = new Set();
  const pushUnique = (w) => {
    const low = w.toLowerCase();
    if (!low || low === garment || added.has(low)) return;
    added.add(low);
    core.push(w);
  };

  for (const kw of styleHits) {
    if (core.length >= 3) break;
    pushUnique(kw);
  }
  for (const w of words) {
    if (core.length >= (garment ? 3 : 4)) break;
    pushUnique(w);
  }
  if (garment) core.push(garment);
  return core.join(" ") || "vintage denim";
}

function extractSize(block, title) {
  const htmlMatch =
    block.match(/Size:\s*([^<\n"]{1,18})/i) ||
    block.match(/tile__details__pipe__size[^>]*>\s*(?:Size:\s*)?([^<\n"]{1,18})/i);
  if (htmlMatch) return decodeHtml(htmlMatch[1]);

  // Poshmark tile-grid-redesign puts the size token right after the price ($XX | [$YY] | SIZE)
  const plain = block.slice(0, 6000).replace(/<[^>]+>/g, " | ").replace(/\s+/g, " ");
  const afterPrice = plain.match(/\$\s*[0-9][0-9,]*(?:\.[0-9]{2})?(?:\s*\|\s*\$\s*[0-9][0-9,]*(?:\.[0-9]{2})?)*\s*(?:\|\s*)+([A-Za-z0-9.\/ ×-]{1,14})\s*\|/);
  if (afterPrice) {
    const cand = afterPrice[1].trim();
    if (/^(?:(?:US|EU|UK)\s*)?(?:XXS|XS|S|M|L|XL|XXL|2XL|3XL|XS\/S|S\/M|M\/L|L\/XL|OS|ONE SIZE|FREE|[0-9]{1,2}(?:\.[05])?|[0-9]{2}\s*[x×]\s*[0-9]{2}|[0-9]{1,2}[PSWL]?)$/i.test(cand)) {
      return cand.toUpperCase();
    }
  }

  const t = String(title || "");
  const dimMatch = t.match(/\b(\d{2}\s*[x×]\s*\d{2})\b/i);
  if (dimMatch) return dimMatch[1].replace(/\s+/g, " ");

  const explicitMatch = t.match(/\b(?:size|sz\.?)\s*([0-9]{1,2}(?:\.[05])?|XXS|XS|S|M|L|XL|XXL|2XL|3XL|OS)\b/i);
  if (explicitMatch) return explicitMatch[1].toUpperCase();

  const euUsMatch = t.match(/\b((?:US|EU|UK)\s*[0-9]{1,2}(?:\.[05])?)\b/i);
  if (euUsMatch) return euUsMatch[1].toUpperCase();

  const genderSizeMatch = t.match(/\b(?:men'?s|women'?s|mens|womens)\s+(XXS|XS|S|M|L|XL|XXL|2XL|3XL|[0-9]{1,2})\b/i);
  if (genderSizeMatch) return genderSizeMatch[1].toUpperCase();

  const trailingSize = t.match(/[\s,\-|]+(XXS|XS|S|M|L|XL|XXL|2XL|3XL)(?:\s*$)/i);
  if (trailingSize) return trailingSize[1].toUpperCase();

  return "See listing";
}

function parsePoshmarkTiles(html, query, retailPrice, department = "") {
  const listings = [];
  const seenUrls = new Set();
  const queryCatIdx = detectCategoryIndex(query);
  const blocks = html.split("tile-grid-redesign__media--wrapper").slice(1, 55);

  for (const block of blocks) {
    const hrefMatch = block.match(/href="(\/listing\/[^"]+)"/);
    const imgMatch =
      block.match(/<img[^>]+src="(https:\/\/di2ponv0v5otw\.cloudfront\.net\/posts\/[^"]+)"[^>]*alt="([^"]*)"/i) ||
      block.match(/<img[^>]+alt="([^"]*)"[^>]*src="(https:\/\/di2ponv0v5otw\.cloudfront\.net\/posts\/[^"]+)"/i);

    if (!hrefMatch || !imgMatch) continue;

    const url = `https://poshmark.com${hrefMatch[1]}`;
    if (seenUrls.has(url)) continue;

    const isSrcFirst = imgMatch[1].startsWith("http");
    const image = isSrcFirst ? imgMatch[1] : imgMatch[2];
    const title = decodeHtml(isSrcFirst ? imgMatch[2] : imgMatch[1]);
    if (!title || !image) continue;
    if (SPAM_LISTING_RE.test(title)) continue;
    if (!isCategoryCompatible(queryCatIdx, title)) continue;
    if (!isGenderCompatible(department, title)) continue;

    const priceMatch = block.match(/\$\s*([0-9][0-9,]*(?:\.[0-9]{2})?)/);
    const priceNum = priceMatch ? parseFloat(priceMatch[1].replace(/,/g, "")) : null;
    if (!priceNum || priceNum <= 0) continue;
    if (retailPrice && priceNum >= retailPrice) continue;

    const size = extractSize(block, title);

    const brandMatch =
      block.match(/tile__details__pipe__brand[^>]*>([^<]+)</i) ||
      block.match(/href="\/brand\/[^"]*"[^>]*>([^<]+)</i);
    const brand = brandMatch ? decodeHtml(brandMatch[1]) : "Secondhand";

    seenUrls.add(url);
    listings.push({
      name: title.length > 52 ? title.slice(0, 49).trim() + "…" : title,
      price: `$${priceNum.toFixed(2)}`,
      priceNum,
      source: "Poshmark",
      labels: ["Listed size", "Condition", "Brand", "Source"],
      facts: [size, "Pre-owned", brand, "Poshmark"],
      why: `Live secondhand match for “${query}” on Poshmark${size !== "See listing" ? ` in size ${size}` : ""}.`,
      url,
      image
    });

    if (listings.length >= 15) break;
  }

  return listings;
}

function parseTheRealRealTiles(html, query, retailPrice) {
  const listings = [];
  const seenUrls = new Set();
  const queryCatIdx = detectCategoryIndex(query);
  const blocks = html.split('data-testid="plp-product/').slice(1, 30);

  for (const block of blocks) {
    const hrefMatch = block.match(/href="(\/products\/[^"]+)"/);
    const imgMatch = block.match(/https:\/\/product-images\.therealreal\.com\/[A-Za-z0-9_.-]+\.(?:jpg|jpeg|png)/i);
    const altMatch = block.match(/<img[^>]+alt="([^"]{3,120})"/i);
    const priceMatch = block.match(/\$\s*([0-9][0-9,]*(?:\.[0-9]{2})?)/);

    if (!hrefMatch || !imgMatch || !altMatch || !priceMatch) continue;

    const url = `https://www.therealreal.com${hrefMatch[1]}`;
    if (seenUrls.has(url)) continue;

    const priceNum = parseFloat(priceMatch[1].replace(/,/g, ""));
    if (!priceNum || priceNum <= 0) continue;
    if (retailPrice && priceNum >= retailPrice) continue;

    const title = decodeHtml(altMatch[1]);
    if (!isCategoryCompatible(queryCatIdx, title)) continue;
    const size = extractSize(block, title);
    seenUrls.add(url);
    listings.push({
      name: title.length > 52 ? title.slice(0, 49).trim() + "…" : title,
      price: `$${priceNum.toFixed(2)}`,
      priceNum,
      source: "The RealReal",
      labels: ["Listed size", "Condition", "Authenticated", "Source"],
      facts: [size, "Consigned", "Yes", "The RealReal"],
      why: `Authenticated consignment match for “${query}” on The RealReal.`,
      url,
      image: `${imgMatch[0]}?auto=webp&width=360&quality=75`
    });

    if (listings.length >= 5) break;
  }

  return listings;
}

async function getEbayToken(clientId, clientSecret) {
  if (ebayTokenCache.token && Date.now() < ebayTokenCache.expiresAt) {
    return ebayTokenCache.token;
  }
  const creds = btoa(`${clientId}:${clientSecret}`);
  const res = await fetch("https://api.ebay.com/identity/v1/oauth2/token", {
    method: "POST",
    headers: {
      Authorization: `Basic ${creds}`,
      "Content-Type": "application/x-www-form-urlencoded"
    },
    body: "grant_type=client_credentials&scope=https%3A%2F%2Fapi.ebay.com%2Foauth%2Fapi_scope"
  });
  if (!res.ok) throw new Error(`eBay auth ${res.status}`);
  const data = await res.json();
  ebayTokenCache = {
    token: data.access_token,
    expiresAt: Date.now() + (data.expires_in - 120) * 1000
  };
  return data.access_token;
}

async function searchEbay(query, retailPrice) {
  const { ebayClientId, ebayClientSecret } = await chrome.storage.local.get([
    "ebayClientId",
    "ebayClientSecret"
  ]);
  if (!ebayClientId || !ebayClientSecret) return [];

  const token = await getEbayToken(ebayClientId, ebayClientSecret);
  const priceFilter = retailPrice ? `,price:[1..${Math.max(1, Math.floor(retailPrice - 1))}],priceCurrency:USD` : "";
  const url = `https://api.ebay.com/buy/browse/v1/item_summary/search?q=${encodeURIComponent(query)}&filter=conditions:{USED}${priceFilter}&limit=5`;

  const res = await fetch(url, {
    headers: {
      Authorization: `Bearer ${token}`,
      "X-EBAY-C-MARKETPLACE-ID": "EBAY_US"
    }
  });
  if (!res.ok) return [];
  const data = await res.json();
  const items = data.itemSummaries || [];

  return items
    .map((item) => {
      const priceNum = parseFloat(item.price?.value || "0");
      if (!priceNum || (retailPrice && priceNum >= retailPrice)) return null;
      const image = item.thumbnailImages?.[0]?.imageUrl || item.image?.imageUrl;
      if (!image || !item.itemWebUrl) return null;
      const title = item.title || query;
      return {
        name: title.length > 52 ? title.slice(0, 49).trim() + "…" : title,
        price: `$${priceNum.toFixed(2)}`,
        priceNum,
        source: "eBay",
        labels: ["Condition", "Shipping", "Seller", "Source"],
        facts: [
          item.condition || "Pre-owned",
          item.shippingOptions?.[0]?.shippingCost?.value === "0.00" ? "Free" : "Check listing",
          item.seller?.username || "Verified",
          "eBay"
        ],
        why: `Pre-owned match for “${query}” on eBay.`,
        url: item.itemWebUrl,
        image
      };
    })
    .filter(Boolean)
    .slice(0, 3);
}

function isGenderCompatible(department, listingTitle) {
  const lower = String(listingTitle || "").toLowerCase();
  // Never recommend Kids/Baby/Toddler/Youth items unless the user is explicitly shopping Kids
  if (department !== "Kids" && /\b(kids?|toddler|baby|infant|youth|boys?|girls?|\d+t)\b/.test(lower)) {
    return false;
  }
  if (!department) return true;
  if (department === "Men" && /\b(women'?s|womens|woman'?s|ladies)\b/.test(lower)) return false;
  if (department === "Women" && /\b(men'?s|mens)\b/.test(lower)) return false;
  return true;
}

function toPoshmarkSize(selectedSize, department = "", garment = "") {
  if (!selectedSize) return "";
  const raw = String(selectedSize).toUpperCase().replace(/^(?:US|EU|EUR|UK)\s*/i, "").trim();
  const isShoe = /\b(shoe|shoes|sneaker|sneakers|boot|boots|loafer|heel|sandal|clog|mule)\b/i.test(garment);
  const num = parseFloat(raw);
  // Convert EU shoe sizes (35–46) to Poshmark US shoe sizes
  if (isShoe && Number.isFinite(num) && num >= 35 && num <= 46) {
    const us = department === "Men" ? Math.round((num - 33) * 2) / 2 : Math.round((num - 30.5) * 2) / 2;
    return String(us);
  }
  return raw;
}

async function searchPoshmark(query, retailPrice, department, color = "", page = 1, size = "") {
  const deptParam = department ? `&department=${encodeURIComponent(department)}` : "";
  const colorParam = color ? `&color=${encodeURIComponent(color)}` : "";
  const sizeParam = size ? `&size[]=${encodeURIComponent(size)}` : "";
  const pageParam = page > 1 ? `&page=${page}` : "";
  const url = `https://poshmark.com/search?query=${encodeURIComponent(query)}&type=listings${deptParam}${colorParam}${sizeParam}${pageParam}`;
  const res = await fetch(url, {
    headers: { Accept: "text/html,application/xhtml+xml", "Accept-Language": "en-US,en;q=0.9" }
  });
  if (!res.ok) return [];
  return parsePoshmarkTiles(await res.text(), query, retailPrice, department);
}

async function searchTheRealReal(query, retailPrice, department) {
  const path = department === "Men" ? "/products/men" : department === "Women" ? "/products/women" : "/products";
  const url = `https://www.therealreal.com${path}?keywords=${encodeURIComponent(query)}`;
  const res = await fetch(url, {
    headers: { Accept: "text/html,application/xhtml+xml", "Accept-Language": "en-US,en;q=0.9" }
  });
  if (!res.ok) return [];
  return parseTheRealRealTiles(await res.text(), query, retailPrice).filter((x) => isGenderCompatible(department, x.name));
}

function sizeMatchesSelected(listedSize, selectedSize) {
  if (!listedSize || !selectedSize || listedSize === "See listing") return false;
  const a = String(listedSize).toUpperCase().replace(/\s+/g, " ").trim();
  const b = String(selectedSize).toUpperCase().replace(/\s+/g, " ").trim();
  if (a === b || a.includes(b) || b.includes(a)) return true;
  // EU shoe size (35–46) to US women/men approximate match
  const euNum = parseFloat(b.replace(/^(EU|EUR)\s*/i, ""));
  const usNum = parseFloat(a.replace(/^US\s*/i, ""));
  if (euNum >= 35 && euNum <= 46 && usNum >= 4 && usNum <= 14) {
    const approxUsW = euNum - 30.5;
    const approxUsM = euNum - 32.5;
    if (Math.abs(usNum - approxUsW) <= 0.6 || Math.abs(usNum - approxUsM) <= 0.6) return true;
  }
  return false;
}

function scoreRelevance(listing, rawTitle, brand, color = "", selectedSize = "") {
  const targetWords = String(rawTitle || "")
    .toLowerCase()
    .replace(/[^a-z0-9\s]/g, " ")
    .split(/\s+/)
    .filter((w) => w.length > 2);
  const titleLower = String(listing.name || "").toLowerCase();
  let score = 0;

  for (const w of targetWords) {
    if (titleLower.includes(w)) score += 3;
  }
  const garment = findGarmentWord(rawTitle);
  if (garment && new RegExp(`\\b${garment}s?\\b`, "i").test(titleLower)) {
    score += 6;
  }
  // Heavily reward matching defining silhouette/style keywords (e.g. "tabi", "chelsea", "trench", "corset")
  const styleHits = extractStyleKeywords(rawTitle);
  for (const kw of styleHits) {
    if (new RegExp(`\\b${kw.replace(/[- ]/g, "[-\\s]?")}\\b`, "i").test(titleLower)) {
      score += 10;
    }
  }
  if (brand && titleLower.includes(brand.toLowerCase())) {
    score += 4;
  }
  if (color && titleLower.includes(color.toLowerCase())) {
    score += 5;
  }
  const listedSize = listing.facts?.[0] || "";
  if (selectedSize && sizeMatchesSelected(listedSize, selectedSize)) {
    score += 6;
  }
  return score;
}

async function searchAllMarketplaces(rawTitle, brand, retailPrice, department = "", color = "", excludeUrls = [], attempt = 0, selectedSize = "") {
  const query = buildCleanQuery(rawTitle, brand, color);
  const excludeSet = new Set(Array.isArray(excludeUrls) ? excludeUrls : []);
  const cacheKey = `${query.toLowerCase()}::${department}::${color}::${selectedSize}::${retailPrice || 0}::${attempt}`;
  if (attempt === 0 && excludeSet.size === 0 && searchCache.has(cacheKey)) {
    return searchCache.get(cacheKey);
  }

  const garment = findGarmentWord(rawTitle);
  const styleHits = extractStyleKeywords(rawTitle);
  const primaryStyle = styleHits[0] || "";
  const colorQuery = color && !query.toLowerCase().includes(color.toLowerCase()) ? `${color} ${query}` : query;
  const poshSize = toPoshmarkSize(selectedSize, department, garment);

  // Progressive refinement strategy:
  // Attempt 0: balanced [color + top descriptors + garment]
  // Attempt 1: tighter exact-match [brand + color + descriptors + garment] (falls back to unseen pool)
  // Attempt 2: style-twin angle [color + alternate descriptors + garment] on page 2
  // Attempt 3+: deeper catalog pages so every reload surfaces fresh unseen listings
  let activeQuery = colorQuery;
  let poshPage = 1;

  if (attempt === 1) {
    if (brand && !colorQuery.toLowerCase().includes(brand.toLowerCase())) {
      activeQuery = `${brand} ${colorQuery}`.trim();
    } else {
      poshPage = 2;
    }
  } else if (attempt >= 2) {
    poshPage = attempt;
    const words = query.split(/\s+/).filter((w) => w.toLowerCase() !== garment);
    const altWord = words.length > 1 ? words[words.length - 1] : words[0] || "";
    activeQuery = [color, altWord, garment].filter(Boolean).join(" ").trim() || colorQuery;
  }

  const [posh, trr, ebay] = await Promise.all([
    searchPoshmark(activeQuery, retailPrice, department, color, poshPage, poshSize).catch(() => []),
    attempt <= 1 ? searchTheRealReal(activeQuery, retailPrice, department).catch(() => []) : Promise.resolve([]),
    attempt === 0 ? searchEbay([department, activeQuery].filter(Boolean).join(" "), retailPrice).catch(() => []) : Promise.resolve([])
  ]);

  let all = [...ebay, ...posh, ...trr].filter((item) => !excludeSet.has(item.url));

  // If fewer than 3 unseen matches in the exact size, top up without the size filter
  if (all.length < 3 && poshSize) {
    const anySizeExtra = await searchPoshmark(activeQuery, retailPrice, department, color, poshPage, "").catch(() => []);
    const seen = new Set([...excludeSet, ...all.map((x) => x.url)]);
    for (const item of anySizeExtra) {
      if (!seen.has(item.url)) {
        seen.add(item.url);
        all.push(item);
      }
    }
  }

  // If fewer than 3 unseen matches, top up from the base query / next page so we always return 3 fresh items
  if (all.length < 3) {
    const fallbackQuery = attempt >= 1 ? colorQuery : (garment ? `${query.split(" ")[0]} ${garment}`.trim() : query.split(" ").slice(0, 2).join(" "));
    const extra = await searchPoshmark(fallbackQuery || query, retailPrice, department, color, attempt >= 1 ? poshPage + 1 : 1).catch(() => []);
    const seen = new Set([...excludeSet, ...all.map((x) => x.url)]);
    for (const item of extra) {
      if (!seen.has(item.url)) {
        seen.add(item.url);
        all.push(item);
      }
    }
  }

  // Style-anchored safety net: keep primary defining style (e.g. "tabi") anchored before broadening to generic garment
  if (all.length < 3 && primaryStyle && garment) {
    const styleExtra = await searchPoshmark([color, primaryStyle, garment].filter(Boolean).join(" "), retailPrice, department, color, 1).catch(() => []);
    const seen = new Set([...excludeSet, ...all.map((x) => x.url)]);
    for (const item of styleExtra) {
      if (!seen.has(item.url)) {
        seen.add(item.url);
        all.push(item);
      }
    }
  }

  // Final safety net: if still < 3 (e.g. very rare style/color), broaden to [color + garment]
  if (all.length < 3 && garment) {
    const broadExtra = await searchPoshmark([color, garment].filter(Boolean).join(" "), retailPrice, department, color, 1).catch(() => []);
    const seen = new Set([...excludeSet, ...all.map((x) => x.url)]);
    for (const item of broadExtra) {
      if (!seen.has(item.url)) {
        seen.add(item.url);
        all.push(item);
      }
    }
  }

  all = all.map((item) => ({
    ...item,
    _score: scoreRelevance(item, rawTitle, brand, color, selectedSize)
  }));

  // Rank by highest relevance match first, then lowest price as tie-breaker
  all.sort((a, b) => (b._score - a._score) || ((a.priceNum || 9999) - (b.priceNum || 9999)));
  const result = { query: activeQuery, listings: all.slice(0, 3) };
  if (attempt === 0 && excludeSet.size === 0 && result.listings.length > 0) {
    searchCache.set(cacheKey, result);
  }
  return result;
}

chrome.runtime.onInstalled.addListener((details) => {
  if (details.reason === "install") {
    chrome.tabs.create({ url: chrome.runtime.getURL("src/onboarding.html") });
  }
});

chrome.action.onClicked.addListener((tab) => {
  if (!tab?.id) return;
  chrome.tabs.sendMessage(tab.id, { type: "CIRKULAR_TOGGLE_TRACKER" }, () => {
    void chrome.runtime.lastError;
  });
});

chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (msg?.type === "CIRKULAR_SEARCH") {
    searchAllMarketplaces(
      msg.title,
      msg.brand,
      msg.retailPrice,
      msg.department,
      msg.color,
      msg.excludeUrls || [],
      msg.attempt || 0,
      msg.selectedSize || ""
    )
      .then((data) => sendResponse({ ok: true, ...data }))
      .catch((err) => sendResponse({ ok: false, error: err.message, listings: [] }));
    return true;
  }
});
