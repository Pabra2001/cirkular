const searchCache = new Map();
let ebayTokenCache = { token: null, expiresAt: 0 };

function decodeHtml(str) {
  return String(str || "")
    .replace(/&amp;/g, "&")
    .replace(/&quot;/g, '"')
    .replace(/&#39;|&apos;/g, "'")
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">")
    .replace(/\s+/g, " ")
    .trim();
}

function buildCleanQuery(rawTitle, brand) {
  const stopWords = /\b(new|with|tags|nwt|nwot|free|shipping|sale|off|limited|edition|official|store|shop|online|men's|women's|mens|womens)\b/gi;
  let q = String(rawTitle || "").replace(/[|–—•·/\\()[\]]/g, " ").replace(stopWords, " ");
  if (brand && !q.toLowerCase().includes(brand.toLowerCase())) {
    q = `${brand} ${q}`;
  }
  const words = q.trim().split(/\s+/).filter((w) => w.length > 1).slice(0, 5);
  return words.join(" ") || "vintage denim";
}

function parsePoshmarkTiles(html, query, retailPrice) {
  const listings = [];
  const seenUrls = new Set();
  const blocks = html.split("tile-grid-redesign__media--wrapper").slice(1, 45);

  for (const block of blocks) {
    const hrefMatch = block.match(/href="(\/listing\/[^"]+)"/);
    const imgMatch =
      block.match(/<img[^>]+src="(https:\/\/di2ponv0v5otw\.cloudfront\.net\/posts\/[^"]+)"[^>]*alt="([^"]*)"/i) ||
      block.match(/<img[^>]+alt="([^"]*)"[^>]*src="(https:\/\/di2ponv0v5otw\.cloudfront\.net\/posts\/[^"]+)"/i);

    if (!hrefMatch || !imgMatch) continue;

    const url = `https://poshmark.com${hrefMatch[1]}`;
    if (seenUrls.has(url)) continue;

    const isSrcFirst = imgMatch[1].startsWith("http");
    const image = isSrcFirst ? imgMatch[1] : imgMatch[2];
    const title = decodeHtml(isSrcFirst ? imgMatch[2] : imgMatch[1]);
    if (!title || !image) continue;

    const priceMatch = block.match(/\$\s*([0-9][0-9,]*(?:\.[0-9]{2})?)/);
    const priceNum = priceMatch ? parseFloat(priceMatch[1].replace(/,/g, "")) : null;
    if (!priceNum || priceNum <= 0) continue;
    if (retailPrice && priceNum >= retailPrice) continue;

    const sizeMatch = block.match(/Size:\s*([^<\n"]{1,18})/i);
    const size = sizeMatch ? decodeHtml(sizeMatch[1]) : "Check listing";

    const brandMatch =
      block.match(/tile__details__pipe__brand[^>]*>([^<]+)</i) ||
      block.match(/href="\/brand\/[^"]*"[^>]*>([^<]+)</i);
    const brand = brandMatch ? decodeHtml(brandMatch[1]) : "Secondhand";

    seenUrls.add(url);
    listings.push({
      name: title.length > 52 ? title.slice(0, 49).trim() + "…" : title,
      price: `$${priceNum.toFixed(2)}`,
      priceNum,
      source: "Poshmark",
      labels: ["Listed size", "Condition", "Brand", "Source"],
      facts: [size, "Pre-owned", brand, "Poshmark"],
      why: `Live secondhand match for “${query}” on Poshmark${size !== "Check listing" ? ` in size ${size}` : ""}.`,
      url,
      image
    });

    if (listings.length >= 4) break;
  }

  return listings;
}

function parseTheRealRealTiles(html, query, retailPrice) {
  const listings = [];
  const seenUrls = new Set();
  const blocks = html.split('data-testid="plp-product/').slice(1, 30);

  for (const block of blocks) {
    const hrefMatch = block.match(/href="(\/products\/[^"]+)"/);
    const imgMatch = block.match(/https:\/\/product-images\.therealreal\.com\/[A-Za-z0-9_.-]+\.(?:jpg|jpeg|png)/i);
    const altMatch = block.match(/<img[^>]+alt="([^"]{3,120})"/i);
    const priceMatch = block.match(/\$\s*([0-9][0-9,]*(?:\.[0-9]{2})?)/);

    if (!hrefMatch || !imgMatch || !altMatch || !priceMatch) continue;

    const url = `https://www.therealreal.com${hrefMatch[1]}`;
    if (seenUrls.has(url)) continue;

    const priceNum = parseFloat(priceMatch[1].replace(/,/g, ""));
    if (!priceNum || priceNum <= 0) continue;
    if (retailPrice && priceNum >= retailPrice) continue;

    const title = decodeHtml(altMatch[1]);
    seenUrls.add(url);
    listings.push({
      name: title.length > 52 ? title.slice(0, 49).trim() + "…" : title,
      price: `$${priceNum.toFixed(2)}`,
      priceNum,
      source: "The RealReal",
      labels: ["Listed size", "Condition", "Authenticated", "Source"],
      facts: ["Check listing", "Consigned", "Yes", "The RealReal"],
      why: `Authenticated consignment match for “${query}” on The RealReal.`,
      url,
      image: `${imgMatch[0]}?auto=webp&width=360&quality=75`
    });

    if (listings.length >= 2) break;
  }

  return listings;
}

async function getEbayToken(clientId, clientSecret) {
  if (ebayTokenCache.token && Date.now() < ebayTokenCache.expiresAt) {
    return ebayTokenCache.token;
  }
  const creds = btoa(`${clientId}:${clientSecret}`);
  const res = await fetch("https://api.ebay.com/identity/v1/oauth2/token", {
    method: "POST",
    headers: {
      Authorization: `Basic ${creds}`,
      "Content-Type": "application/x-www-form-urlencoded"
    },
    body: "grant_type=client_credentials&scope=https%3A%2F%2Fapi.ebay.com%2Foauth%2Fapi_scope"
  });
  if (!res.ok) throw new Error(`eBay auth ${res.status}`);
  const data = await res.json();
  ebayTokenCache = {
    token: data.access_token,
    expiresAt: Date.now() + (data.expires_in - 120) * 1000
  };
  return data.access_token;
}

async function searchEbay(query, retailPrice) {
  const { ebayClientId, ebayClientSecret } = await chrome.storage.local.get([
    "ebayClientId",
    "ebayClientSecret"
  ]);
  if (!ebayClientId || !ebayClientSecret) return [];

  const token = await getEbayToken(ebayClientId, ebayClientSecret);
  const priceFilter = retailPrice ? `,price:[1..${Math.max(1, Math.floor(retailPrice - 1))}],priceCurrency:USD` : "";
  const url = `https://api.ebay.com/buy/browse/v1/item_summary/search?q=${encodeURIComponent(query)}&filter=conditions:{USED}${priceFilter}&limit=5`;

  const res = await fetch(url, {
    headers: {
      Authorization: `Bearer ${token}`,
      "X-EBAY-C-MARKETPLACE-ID": "EBAY_US"
    }
  });
  if (!res.ok) return [];
  const data = await res.json();
  const items = data.itemSummaries || [];

  return items
    .map((item) => {
      const priceNum = parseFloat(item.price?.value || "0");
      if (!priceNum || (retailPrice && priceNum >= retailPrice)) return null;
      const image = item.thumbnailImages?.[0]?.imageUrl || item.image?.imageUrl;
      if (!image || !item.itemWebUrl) return null;
      const title = item.title || query;
      return {
        name: title.length > 52 ? title.slice(0, 49).trim() + "…" : title,
        price: `$${priceNum.toFixed(2)}`,
        priceNum,
        source: "eBay",
        labels: ["Condition", "Shipping", "Seller", "Source"],
        facts: [
          item.condition || "Pre-owned",
          item.shippingOptions?.[0]?.shippingCost?.value === "0.00" ? "Free" : "Check listing",
          item.seller?.username || "Verified",
          "eBay"
        ],
        why: `Pre-owned match for “${query}” on eBay.`,
        url: item.itemWebUrl,
        image
      };
    })
    .filter(Boolean)
    .slice(0, 3);
}

async function searchPoshmark(query, retailPrice) {
  const url = `https://poshmark.com/search?query=${encodeURIComponent(query)}&type=listings`;
  const res = await fetch(url, {
    headers: { Accept: "text/html,application/xhtml+xml", "Accept-Language": "en-US,en;q=0.9" }
  });
  if (!res.ok) return [];
  return parsePoshmarkTiles(await res.text(), query, retailPrice);
}

async function searchTheRealReal(query, retailPrice) {
  const url = `https://www.therealreal.com/products?keywords=${encodeURIComponent(query)}`;
  const res = await fetch(url, {
    headers: { Accept: "text/html,application/xhtml+xml", "Accept-Language": "en-US,en;q=0.9" }
  });
  if (!res.ok) return [];
  return parseTheRealRealTiles(await res.text(), query, retailPrice);
}

async function searchAllMarketplaces(rawTitle, brand, retailPrice) {
  const query = buildCleanQuery(rawTitle, brand);
  const cacheKey = `${query.toLowerCase()}::${retailPrice || 0}`;
  if (searchCache.has(cacheKey)) {
    return searchCache.get(cacheKey);
  }

  const [posh, trr, ebay] = await Promise.all([
    searchPoshmark(query, retailPrice).catch(() => []),
    searchTheRealReal(query, retailPrice).catch(() => []),
    searchEbay(query, retailPrice).catch(() => [])
  ]);

  // Interleave marketplaces so the user gets variety, prioritizing best deals
  const combined = [];
  const pools = [ebay, posh, trr];
  for (let i = 0; i < 4 && combined.length < 3; i++) {
    for (const pool of pools) {
      if (pool[i] && combined.length < 3) combined.push(pool[i]);
    }
  }

  combined.sort((a, b) => (a.priceNum || 9999) - (b.priceNum || 9999));
  const result = { query, listings: combined.slice(0, 3) };
  if (result.listings.length > 0) searchCache.set(cacheKey, result);
  return result;
}

chrome.runtime.onInstalled.addListener((details) => {
  if (details.reason === "install") {
    chrome.tabs.create({ url: chrome.runtime.getURL("src/onboarding.html") });
  }
});

chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (msg?.type === "CIRKULAR_SEARCH") {
    searchAllMarketplaces(msg.title, msg.brand, msg.retailPrice)
      .then((data) => sendResponse({ ok: true, ...data }))
      .catch((err) => sendResponse({ ok: false, error: err.message, listings: [] }));
    return true;
  }
});
