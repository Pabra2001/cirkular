const toggleAutoBtn = document.getElementById("toggle-auto");
const powerLabel = document.getElementById("power-label");
const openOnboardingLink = document.getElementById("open-onboarding");
const savedListEl = document.getElementById("saved-list");
const savedTabBtn = document.getElementById("saved-tab-btn");
const statDollarsEl = document.getElementById("stat-saved-dollars");
const statEvalEl = document.getElementById("stat-evaluated");
const statCountEl = document.getElementById("stat-saved-count");

const tabs = Array.from(document.querySelectorAll(".tab"));
const panels = {
  profile: document.getElementById("panel-profile"),
  saved: document.getElementById("panel-saved")
};

tabs.forEach((tab) => {
  tab.addEventListener("click", () => {
    const target = tab.dataset.tab;
    tabs.forEach((t) => t.classList.toggle("active", t === tab));
    Object.entries(panels).forEach(([key, el]) => el.classList.toggle("active", key === target));
  });
});

openOnboardingLink?.addEventListener("click", (e) => {
  e.preventDefault();
  chrome.tabs.create({ url: chrome.runtime.getURL("src/onboarding.html") });
});

function updatePower(enabled) {
  toggleAutoBtn.setAttribute("aria-pressed", String(enabled));
  powerLabel.textContent = enabled ? "Active" : "Paused";
}

function renderDashboard() {
  if (typeof chrome === "undefined" || !chrome.storage) return;
  chrome.storage.local.get(
    { enabled: true, savedItems: [], stats: { evaluated: 0, savedDollars: 0, buys: 0 } },
    ({ enabled, savedItems, stats }) => {
      updatePower(enabled);

      const savedPotential = savedItems.reduce((sum, item) => sum + (Number(item.savings) || 0), 0);
      const totalDollars = Math.round((Number(stats.savedDollars) || 0) + savedPotential);
      statDollarsEl.textContent = `$${totalDollars}`;
      statEvalEl.textContent = String(stats.evaluated || 0);
      statCountEl.textContent = String(savedItems.length);
      savedTabBtn.textContent = `Saved (${savedItems.length})`;

      if (savedItems.length === 0) {
        savedListEl.innerHTML = `<div class="empty">No saved items yet.<br>Bookmark any secondhand find to save it here.</div>`;
        return;
      }

      savedListEl.innerHTML = savedItems
        .map(
          (item, i) => `
          <div class="saved-item">
            <img src="${item.image}" alt="">
            <div class="saved-info">
              <a href="${item.url}" target="_blank" rel="noopener">${item.name}</a>
              <div class="saved-meta">${item.price} <span>· ${item.source || "Poshmark"}</span></div>
            </div>
            <button class="remove-btn" type="button" data-remove="${i}" aria-label="Remove saved item">×</button>
          </div>`
        )
        .join("");

      savedListEl.querySelectorAll("[data-remove]").forEach((btn) => {
        btn.addEventListener("click", () => {
          const idx = Number(btn.dataset.remove);
          savedItems.splice(idx, 1);
          chrome.storage.local.set({ savedItems }, renderDashboard);
        });
      });
    }
  );
}

toggleAutoBtn.addEventListener("click", () => {
  chrome.storage.local.get({ enabled: true }, ({ enabled }) => {
    const next = !enabled;
    chrome.storage.local.set({ enabled: next }, () => updatePower(next));
  });
});

renderDashboard();
