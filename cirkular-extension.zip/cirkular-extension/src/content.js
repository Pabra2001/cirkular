(() => {
  if (window.__cirkularMounted) return;
  window.__cirkularMounted = true;

  const SECONDHAND_HOSTS = [
    "poshmark.com",
    "depop.com",
    "grailed.com",
    "therealreal.com",
    "ebay.com",
    "mercari.com",
    "thredup.com",
    "vestiairecollective.com",
    "vinted.com",
    "cirkular.pages.dev"
  ];
  const isSecondhandSite = SECONDHAND_HOSTS.some(
    (h) => location.hostname === h || location.hostname.endsWith("." + h)
  );

  const FALLBACK_LISTINGS = [
    {
      name: "Levi’s SilverTab Loose",
      price: "$24.00",
      source: "Poshmark",
      labels: ["Listed size", "Condition", "Wash", "Cut"],
      facts: ["36 × 34", "Pre-owned", "Light blue", "Loose, wide leg"],
      why: "Faded blue with paint splatter and a loose leg. The seller notes a knee rip and frayed hems.",
      url: "https://poshmark.com/listing/Levis-SilverTab-Loose-Jeans-Mens-36x34-Light-Wash-Distressed-Paint-Splatter-90s-6ae259fc06c773904478166d",
      image: "https://di2ponv0v5otw.cloudfront.net/posts/2026/10/28/6ae259fc06c773904478166d/m_6ae259fc06c773904478166e.jpg"
    },
    {
      name: "Levi’s 569 Loose Straight",
      price: "$30.00",
      source: "Poshmark",
      labels: ["Listed size", "Condition", "Wash", "Cut"],
      facts: ["36 × 32", "Pre-owned", "Light to medium blue", "Loose straight"],
      why: "The faded blue wash, whiskering, and paint marks echo the retail pair. The 569 has a straighter leg.",
      url: "https://poshmark.com/listing/Levis-569-Loose-Straight-Jeans-Mens-36x32-Light-Wash-Paint-Splatter-Denim-6adf9f0a684147eefcc7e88b",
      image: "https://di2ponv0v5otw.cloudfront.net/posts/2026/10/26/6adf9f0a684147eefcc7e88b/m_6adf9f0bab650b2c1417ffc4.jpg"
    },
    {
      name: "Paint-splatter barrel jeans",
      price: "$32.00",
      source: "Poshmark",
      labels: ["Listed size", "Condition", "Wash", "Cut"],
      facts: ["Women’s M", "Like new", "Faded light blue", "Baggy barrel leg"],
      why: "Brown and white splatter gives this pair a dirty-wash look. A drawstring waist and barrel leg change the fit.",
      url: "https://poshmark.com/listing/Barrel-Leg-Jeans-Paint-Splatter-Baggy-Denim-Y2K-Skater-Streetwear-Size-M-6ad937c7de48834720d99dcf",
      image: "https://di2ponv0v5otw.cloudfront.net/posts/2026/10/21/6ad937c7de48834720d99dcf/m_6ad938118974d0d3c65496e3.jpg"
    }
  ];

  const FIBER_SCORES = {
    "organic cotton": 92,
    "hemp": 94,
    "linen": 92,
    "flax": 92,
    "tencel": 85,
    "lyocell": 85,
    "recycled wool": 88,
    "recycled cotton": 86,
    "wool": 82,
    "merino": 82,
    "cashmere": 78,
    "cotton": 78,
    "silk": 76,
    "modal": 72,
    "leather": 68,
    "suede": 66,
    "recycled polyester": 60,
    "recycled nylon": 60,
    "viscose": 52,
    "rayon": 50,
    "elastane": 38,
    "spandex": 38,
    "polyurethane": 28,
    "polyester": 25,
    "nylon": 25,
    "polyamide": 25,
    "acrylic": 18,
    "pvc": 10
  };

  let hostEl = null;
  let detectedProduct = null;
  let detectedKore = null;
  let liveListings = null;

  function parsePrice(val) {
    if (typeof val === "number" && !Number.isNaN(val)) return val;
    if (typeof val !== "string") return null;
    const cleaned = val.replace(/[^0-9.]/g, "");
    const num = parseFloat(cleaned);
    return Number.isFinite(num) && num > 0 ? num : null;
  }

  function getStoreName() {
    const ogSite = document.querySelector('meta[property="og:site_name"]')?.content?.trim();
    if (ogSite) return ogSite;
    const host = location.hostname.replace(/^www\./, "");
    const base = host.split(".")[0] || host;
    return base.charAt(0).toUpperCase() + base.slice(1);
  }

  const COLOR_MAP = [
    ["black", "Black"], ["charcoal", "Black"], ["noir", "Black"], ["onyx", "Black"],
    ["white", "White"], ["ivory", "Cream"], ["cream", "Cream"], ["ecru", "Cream"], ["off-white", "White"],
    ["gray", "Gray"], ["grey", "Gray"], ["heather", "Gray"], ["slate", "Gray"],
    ["brown", "Brown"], ["taupe", "Tan"], ["chocolate", "Brown"], ["espresso", "Brown"], ["camel", "Tan"], ["beige", "Tan"], ["khaki", "Tan"], ["sand", "Tan"],
    ["navy", "Blue"], ["blue", "Blue"], ["indigo", "Blue"], ["cobalt", "Blue"], ["denim", "Blue"],
    ["green", "Green"], ["olive", "Green"], ["sage", "Green"], ["emerald", "Green"], ["forest", "Green"],
    ["pink", "Pink"], ["rose", "Pink"], ["blush", "Pink"], ["magenta", "Pink"],
    ["red", "Red"], ["burgundy", "Red"], ["maroon", "Red"], ["crimson", "Red"], ["wine", "Red"],
    ["purple", "Purple"], ["lavender", "Purple"], ["lilac", "Purple"], ["plum", "Purple"],
    ["orange", "Orange"], ["rust", "Orange"], ["terracotta", "Orange"],
    ["yellow", "Yellow"], ["mustard", "Yellow"], ["gold", "Gold"], ["silver", "Silver"]
  ];

  function detectColor(title) {
    const colorEl = document.querySelector(
      '[class*="selected-color" i], [class*="color-name" i], [data-testid*="color" i]'
    );
    const bodySnippet = (document.body?.innerText || "").slice(0, 4000);
    const supplierMatch = bodySnippet.match(/supplier color:\s*([a-z\s-]{3,24})/i);
    const zaraColorMatch = bodySnippet.match(/\b(BLACK|WHITE|BROWN|TAUPE|PINK|BLUE|NAVY|GREEN|OLIVE|RED|GRAY|GREY|BEIGE|CREAM|ECRU|IVORY|CAMEL|KHAKI)\s*\|/);
    const haystack = [
      colorEl?.textContent || "",
      supplierMatch?.[1] || "",
      zaraColorMatch?.[1] || "",
      title || ""
    ].join(" ").toLowerCase();

    for (const [kw, canonical] of COLOR_MAP) {
      if (new RegExp(`\\b${kw}\\b`, "i").test(haystack)) return canonical;
    }
    return "";
  }

  function detectDepartment(title) {
    const haystack = [
      location.pathname,
      document.querySelector('nav[aria-label*="breadcrumb" i], [class*="breadcrumb" i]')?.textContent || "",
      title || ""
    ].join(" ").toLowerCase();

    if (/\b(kids|boys|girls|youth|toddler|baby)\b/.test(haystack)) return "Kids";
    if (/(?:^|[\s/_-])(women|womens|woman|ladies|womenswear|female)(?:[\s/_-]|$)/.test(haystack)) return "Women";
    if (/(?:^|[\s/_-])(men|mens|man|menswear|male)(?:[\s/_-]|$)/.test(haystack)) return "Men";
    return "";
  }

  function productImage(value) {
    const images = Array.isArray(value) ? value : [value];
    for (const image of images) {
      const source = typeof image === "string" ? image : image?.contentUrl || image?.url;
      if (!source) continue;
      try {
        const url = new URL(source, location.href);
        if (url.protocol === "https:" || url.protocol === "http:") return url.href;
      } catch {
        continue;
      }
    }
    return "";
  }

  function findProductInLd(node) {
    if (!node || typeof node !== "object") return null;
    if (Array.isArray(node)) {
      for (const item of node) {
        const found = findProductInLd(item);
        if (found) return found;
      }
      return null;
    }
    const type = node["@type"];
    const isProduct =
      type === "Product" ||
      (Array.isArray(type) && type.includes("Product"));
    if (isProduct && node.name) {
      const offers = Array.isArray(node.offers) ? node.offers[0] : node.offers;
      const price = parsePrice(offers?.price ?? offers?.lowPrice ?? node.price);
      return {
        name: String(node.name).trim(),
        brand: typeof node.brand === "string" ? node.brand : node.brand?.name || "",
        image: productImage(node.image),
        material: typeof node.material === "string" ? node.material : "",
        price,
        store: getStoreName()
      };
    }
    if (node["@graph"]) return findProductInLd(node["@graph"]);
    return null;
  }

  function extractDomPrice() {
    const selectors = [
      ".money-amount__main",
      '[class*="price-current" i]',
      '[class*="sale-price" i]',
      '[data-testid*="price" i]',
      '[itemprop="price"]',
      '[class*="price" i]'
    ];
    const foundPrices = [];
    for (const sel of selectors) {
      const els = document.querySelectorAll(sel);
      for (const el of els) {
        if (el.closest("s, del, strike")) continue;
        const txt = (el.getAttribute("content") || el.textContent || "").trim();
        if (!txt || txt.length > 24) continue;
        const m = txt.match(/\$\s*([0-9][0-9,]*(?:\.[0-9]{1,2})?)/) || (el.hasAttribute("content") ? txt.match(/([0-9]+(?:\.[0-9]{1,2})?)/) : null);
        if (m) {
          const val = parsePrice(m[1]);
          if (val && val >= 5 && val <= 25000) foundPrices.push(val);
        }
      }
      if (foundPrices.length > 0) break;
    }
    if (foundPrices.length === 0) return null;
    return Math.min(...foundPrices);
  }

  function detectProductPage() {
    const domPrice = extractDomPrice();
    const pageImage = productImage(document.querySelector('meta[property="og:image"]')?.content);
    const scripts = document.querySelectorAll('script[type="application/ld+json"]');
    for (const s of scripts) {
      try {
        const data = JSON.parse(s.textContent);
        const found = findProductInLd(data);
        if (found) {
          if (domPrice && (!found.price || domPrice < found.price)) {
            found.price = domPrice;
          }
          return { ...found, image: found.image || pageImage };
        }
      } catch {
        // Ignore malformed JSON-LD blocks
      }
    }

    const ogType = document.querySelector('meta[property="og:type"]')?.content?.toLowerCase() || "";
    const metaPrice =
      document.querySelector('meta[property="product:price:amount"]')?.content ||
      document.querySelector('meta[property="og:price:amount"]')?.content;
    const parsedMetaPrice = parsePrice(metaPrice);
    const bestPrice = domPrice && parsedMetaPrice ? Math.min(domPrice, parsedMetaPrice) : (domPrice || parsedMetaPrice);

    // Only activate on an actual single-product detail page (must have og:type=product or an Add to bag/cart button)
    const hasAddButton = Array.from(document.querySelectorAll("button, a[role='button']")).some((el) => {
      const txt = (el.textContent || "").trim();
      return /^(add|add to bag|add to cart|add to basket|buy now)$/i.test(txt);
    });

    if ((ogType.includes("product") || hasAddButton) && bestPrice) {
      const title =
        document.querySelector("h1")?.textContent?.trim() ||
        document.querySelector('meta[property="og:title"]')?.content?.trim() ||
        document.title.trim();
      return {
        name: title,
        brand: document.querySelector('meta[property="product:brand"]')?.content || "",
        image: pageImage,
        material: "",
        price: bestPrice,
        store: getStoreName()
      };
    }

    return null;
  }

  function evaluateKore(product) {
    const textSource = [
      product?.material || "",
      document.body?.innerText?.slice(0, 14000) || ""
    ].join(" ");

    const fiberRegex = /(\d{1,3})\s*%\s*(organic cotton|recycled polyester|recycled nylon|recycled wool|recycled cotton|cotton|polyester|nylon|polyamide|wool|merino|cashmere|linen|flax|hemp|silk|viscose|rayon|tencel|lyocell|modal|elastane|spandex|acrylic|polyurethane|leather|suede|pvc)\b/gi;
    const matches = [];
    const seen = new Set();
    let m;
    while ((m = fiberRegex.exec(textSource)) !== null) {
      const pct = parseInt(m[1], 10);
      const fiber = m[2].toLowerCase();
      if (pct > 0 && pct <= 100 && !seen.has(fiber)) {
        seen.add(fiber);
        matches.push({ pct, fiber });
      }
      if (matches.length >= 4) break;
    }

    if (matches.length === 0) return null;

    let totalPct = matches.reduce((sum, x) => sum + x.pct, 0);
    if (totalPct <= 0) totalPct = 100;

    let weighted = 0;
    for (const item of matches) {
      const base = FIBER_SCORES[item.fiber] ?? 50;
      weighted += base * (item.pct / totalPct);
    }

    // Penalize complex multi-fiber blends slightly (harder to recycle)
    if (matches.length >= 3) weighted -= 6;

    const grade =
      weighted >= 84 ? "A" :
      weighted >= 70 ? "B" :
      weighted >= 54 ? "C" :
      weighted >= 35 ? "D" : "F";

    const summary = matches.map((x) => `${x.pct}% ${x.fiber}`).join(", ");
    return { grade, summary };
  }

  async function injectFontFace() {
    if (window.__cirkularFontLoaded) return;
    window.__cirkularFontLoaded = true;
    try {
      const res = await fetch(chrome.runtime.getURL("assets/inter.woff2"));
      const buf = await res.arrayBuffer();
      const face = new FontFace("Cirkular Inter", buf, { weight: "100 900", style: "normal" });
      await face.load();
      document.fonts.add(face);
    } catch {
      // Fallback to system sans-serif if font load fails
    }
  }

  function fetchLiveListings(product) {
    return new Promise((resolve) => {
      if (!product?.name) {
        resolve([]);
        return;
      }
      chrome.runtime.sendMessage(
        {
          type: "CIRKULAR_SEARCH",
          title: product.name,
          brand: product.brand,
          retailPrice: product.price,
          department: detectDepartment(product.name),
          color: detectColor(product.name)
        },
        (res) => {
          if (chrome.runtime.lastError || !res?.ok || !res.listings?.length) {
            resolve([]);
            return;
          }
          resolve(res.listings);
        }
      );
    });
  }

  async function mountWidget(productInfo, { force = false } = {}) {
    if (hostEl) return;
    detectedKore = evaluateKore(productInfo);

    // Never interrupt shopping on A-grade sustainable items
    if (!force && detectedKore?.grade === "A") return;

    await injectFontFace();
    const listings = liveListings || (await fetchLiveListings(productInfo));
    liveListings = listings;

    // Never pop up with fake placeholders if no real secondhand matches exist
    if (!listings.length) return;

    if (hostEl) return;
    chrome.storage.local.get({ stats: { evaluated: 0, savedDollars: 0, buys: 0 } }, ({ stats }) => {
      stats.evaluated = (stats.evaluated || 0) + 1;
      chrome.storage.local.set({ stats });
    });
    hostEl = document.createElement("div");
    hostEl.id = "cirkular-extension-root";
    const shadow = hostEl.attachShadow({ mode: "open" });

    const link = document.createElement("link");
    link.rel = "stylesheet";
    link.href = chrome.runtime.getURL("src/plugin.css");
    shadow.appendChild(link);

    const wordmarkStyle = document.createElement("style");
    wordmarkStyle.textContent = `:host {
      --wordmark-url: url("${chrome.runtime.getURL("assets/wordmark.png")}");
      --mark-url: url("${chrome.runtime.getURL("assets/mark.svg")}");
    }`;
    shadow.appendChild(wordmarkStyle);

    const stage = document.createElement("main");
    stage.className = "stage rail";
    stage.setAttribute("aria-label", "Cirkular browser plug-in");
    stage.innerHTML = `
      <div class="shell">
        <div class="arrangement">
          <button class="mark" type="button" aria-label="CIRKULAR · View KORE material analysis" aria-expanded="false" aria-controls="recommendations detail"><span class="mark-icon" aria-hidden="true"></span></button>
          <div id="recommendations" role="group" aria-label="Three secondhand finds" hidden></div>
        </div>
        <section class="detail" id="detail" aria-label="Listing details" hidden></section>
      </div>
    `;
    shadow.appendChild(stage);
    document.documentElement.appendChild(hostEl);

    initRecommendations(shadow, {
      listings,
      retailPrice: productInfo?.price || null,
      storeName: productInfo?.store || "Retail",
      comparePrice: Boolean(productInfo?.price),
      kore: detectedKore,
      retailItem: productInfo,
      autoOpen: true
    });
  }

  function unmountWidget() {
    if (hostEl) {
      hostEl.remove();
      hostEl = null;
    }
  }

  function initRecommendations(root, { listings, comparePrice = true, retailPrice = null, storeName = "Retail", kore = null, retailItem, autoOpen = true }) {
    const rail = root.querySelector(".arrangement");
    const mark = root.querySelector(".mark");
    const recommendations = root.querySelector("#recommendations");
    const detail = root.querySelector("#detail");
    const reduce = matchMedia("(prefers-reduced-motion: reduce)");
    let selected = -1;
    let showingKore = false;
    let returnListing = 0;
    let ringMotion = null;

    const buttons = listings.map((product, index) => {
      const button = document.createElement("button");
      button.type = "button";
      button.className = "thumb";
      button.setAttribute("aria-controls", detail.id);
      const img = new Image();
      img.src = product.image;
      img.alt = "";
      button.append(img);
      button.addEventListener("click", () => select(selected === index ? -1 : index));
      recommendations.append(button);
      return button;
    });
    updateCue();

    mark.addEventListener("click", () => {
      if (recommendations.hidden) {
        setOpen(true);
      } else if (!showingKore) {
        showKoreCard();
      } else {
        setOpen(false);
      }
    });
    root.addEventListener("keydown", (event) => {
      if (event.key !== "Escape" || recommendations.hidden) return;
      if (showingKore) {
        select(returnListing);
      } else if (selected >= 0) {
        select(-1, true);
      } else {
        setOpen(false);
        mark.focus();
      }
    });
    window.addEventListener("resize", stopMotion);
    reduce.addEventListener("change", stopMotion);

    function updateCue() {
      buttons.forEach((button, index) => {
        const suggested = selected < 0 && index === 0;
        const product = listings[index];
        button.toggleAttribute("data-suggested", suggested);
        button.toggleAttribute("data-picked", index === selected);
        button.setAttribute("aria-expanded", String(index === selected));
        button.setAttribute(
          "aria-label",
          product.name + ", " + product.price + (suggested ? ", suggested pick" : "")
        );
      });
    }

    function dismissAll() {
      showingKore = false;
      select(-1);
      if (reduce.matches) {
        setOpen(false);
        unmountWidget();
        return;
      }
      setTimeout(() => {
        setOpen(false);
        setTimeout(() => {
          mark.classList.add("dismiss-finish");
          setTimeout(() => unmountWidget(), 760);
        }, 260);
      }, 220);
    }

    let heightMotion;

    function animateDetailHeight(previousHeight) {
      heightMotion?.cancel();
      detail.classList.remove("resizing-detail");
      const nextHeight = detail.offsetHeight;
      if (!previousHeight || previousHeight === nextHeight || reduce.matches) return;
      detail.classList.add("resizing-detail");
      heightMotion = detail.animate(
        [{ height: `${previousHeight}px` }, { height: `${nextHeight}px` }],
        { duration: 300, easing: "cubic-bezier(.22,.8,.3,1)" }
      );
      heightMotion.onfinish = () => detail.classList.remove("resizing-detail");
    }

    function showKoreCard() {
      const previousHeight = detail.offsetHeight;
      returnListing = selected >= 0 ? selected : 0;
      selected = -1;
      showingKore = true;
      ringMotion?.classList.remove("ring-travel");
      updateCue();
      detail.hidden = false;

      const grade = kore?.grade;
      const heading = grade ? `Why ${["A", "F"].includes(grade) ? "an" : "a"} ${grade}?` : "Why no grade?";
      detail.innerHTML = `
        <div class="detail-top">
          <span class="card-source"><span class="card-brand" role="img" aria-label="Cirkular"></span><span class="meta">· KORE</span></span>
          <button class="close" type="button" aria-label="Close KORE analysis">×</button>
        </div>
        <div class="kore-item">
          <img class="kore-item-photo" alt="" hidden>
          <div>
            <span class="meta"></span>
            <strong></strong>
            <p>Item analysis</p>
          </div>
        </div>
        <div class="kore-summary">
          <h2>${heading}</h2>
          <p>${grade ? "KORE grades the fiber blend disclosed on the retail page." : "KORE couldn’t find fiber percentages to grade this item."}</p>
        </div>
        <dl class="kore-evidence">
          <div><dt>Quality</dt><dd></dd></div>
          <div><dt>Production</dt><dd>Factory and labor practices unverified.</dd></div>
          <div><dt>Durability</dt><dd>Unknown. Wear and repair evidence unverified.</dd></div>
          <div><dt>Transparency</dt><dd>${grade ? "Fiber percentages found. Supplier details unverified." : "Fiber percentages not found."}</dd></div>
        </dl>
        <button class="kore-back" type="button">
          Back to recommendations
          <svg viewBox="0 0 24 24" width="18" height="18" aria-hidden="true"><path d="m10 6-5 5 5 5M5 11h10a4 4 0 0 1 4 4v2" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>
        </button>
      `;
      detail.querySelector(".kore-item .meta").textContent = retailItem?.brand || storeName;
      detail.querySelector(".kore-item strong").textContent = retailItem?.name || "Retail item";
      if (retailItem?.image) {
        const photo = detail.querySelector(".kore-item-photo");
        photo.hidden = false;
        photo.addEventListener("error", () => { photo.style.visibility = "hidden"; }, { once: true });
        photo.src = retailItem.image;
      }
      detail.querySelector(".kore-evidence dd").textContent = kore?.summary
        ? `Detected fibers: ${kore.summary}. Construction unverified.`
        : "Fiber composition not disclosed. Construction unverified.";
      detail.querySelector(".close").addEventListener("click", dismissAll);
      const back = detail.querySelector(".kore-back");
      back.addEventListener("click", () => select(returnListing));
      animateDetailHeight(previousHeight);
      back.focus({ preventScroll: true });
    }

    function select(index, restoreFocus = false, focusDetail = true) {
      const previousHeight = showingKore ? detail.offsetHeight : 0;
      showingKore = false;
      const previous = selected;
      selected = index;
      ringMotion?.classList.remove("ring-travel");
      updateCue();

      const source = previous >= 0 ? previous : 0;
      if (index >= 0 && index !== source && !reduce.matches) {
        const target = buttons[index];
        const distance = buttons[source].offsetTop - target.offsetTop;
        target.style.setProperty("--ring-offset", `${distance}px`);
        target.classList.add("ring-travel");
        ringMotion = target;
      }

      detail.hidden = selected < 0;
      if (detail.hidden) {
        animateDetailHeight(0);
        if (restoreFocus && buttons[previous]) buttons[previous].focus({ preventScroll: true });
        return;
      }

      const product = listings[selected];
      const listingPrice = parsePrice(product.price) || 0;
      const diff = retailPrice - listingPrice;
      const showDeal = comparePrice && diff > 0;
      const labels = product.labels ?? ["Listed size", "Condition", "Brand", "Source"];

      detail.innerHTML = `
        <div class="detail-top">
          <span class="card-source"><span class="card-brand" role="img" aria-label="Cirkular"></span><span class="meta">· ${product.source || "Poshmark"}</span></span>
          <div class="detail-actions">
            <button class="save-btn" type="button" aria-label="Save item" aria-pressed="false" title="Save to CIRKULAR">
              <svg viewBox="0 0 16 16" width="15" height="15" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M3.5 2.5h9v11L8 10.5 3.5 13.5v-11Z"/></svg>
            </button>
            <button class="close" type="button" aria-label="Close details"><svg viewBox="0 0 16 16" width="15" height="15" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" aria-hidden="true"><path d="M4 4l8 8M12 4l-8 8"/></svg></button>
          </div>
        </div>
        <div class="product">
          <img src="${product.image}" alt="">
          <div>
            <span class="meta">Secondhand listing</span>
            <h2></h2>
            <strong>${product.price}</strong>
            ${showDeal ? `<div class="deal"><s>$${retailPrice.toFixed(0)} at ${storeName}</s><span class="saving">$${diff.toFixed(2)} less</span></div>` : ""}
          </div>
        </div>
        <p class="why"></p>
        <dl class="metrics">
          ${labels.map((label, i) => `<div><dt>${label}</dt><dd>${product.facts[i]}</dd></div>`).join("")}
        </dl>
        <a class="buy" href="${product.url}" target="_blank" rel="noopener">
          <span>View listing</span>
          <svg viewBox="0 0 16 16" aria-hidden="true"><path d="M4 12 12 4M5 4h7v7" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>
        </a>
        <p class="listing-note">Shipping and tax extra.</p>
      `;

      const compactName = product.name.replace(
        /^(Women['’]s Cream High-Neck) Pea\s*Coat(?:\s+with\b.*)?$/i,
        "Women’s Cream High-Neck Peacoat"
      );
      detail.querySelector(".product h2").textContent = compactName;
      detail.querySelector(".why").textContent = product.why;

      const close = detail.querySelector(".close");
      close.addEventListener("click", dismissAll);

      const saveBtn = detail.querySelector(".save-btn");
      const buyLink = detail.querySelector(".buy");
      chrome.storage.local.get({ savedItems: [] }, ({ savedItems }) => {
        const isSaved = savedItems.some((item) => item.url === product.url);
        saveBtn.setAttribute("aria-pressed", String(isSaved));
        if (isSaved) saveBtn.querySelector("path").setAttribute("fill", "currentColor");
      });

      saveBtn.addEventListener("click", () => {
        chrome.storage.local.get({ savedItems: [], stats: { evaluated: 0, savedDollars: 0, buys: 0 } }, ({ savedItems, stats }) => {
          const exists = savedItems.findIndex((item) => item.url === product.url);
          if (exists >= 0) {
            savedItems.splice(exists, 1);
            saveBtn.setAttribute("aria-pressed", "false");
            saveBtn.querySelector("path").setAttribute("fill", "none");
          } else {
            savedItems.unshift({
              name: product.name,
              price: product.price,
              source: product.source || "Poshmark",
              url: product.url,
              image: product.image,
              savings: showDeal ? Number(diff.toFixed(2)) : 0,
              savedAt: Date.now()
            });
            saveBtn.setAttribute("aria-pressed", "true");
            saveBtn.querySelector("path").setAttribute("fill", "currentColor");
          }
          chrome.storage.local.set({ savedItems: savedItems.slice(0, 50), stats });
        });
      });

      buyLink.addEventListener("click", () => {
        chrome.storage.local.get({ stats: { evaluated: 0, savedDollars: 0, buys: 0 } }, ({ stats }) => {
          stats.buys = (stats.buys || 0) + 1;
          if (showDeal) stats.savedDollars = Number(((stats.savedDollars || 0) + diff).toFixed(2));
          chrome.storage.local.set({ stats });
        });
      });

      animateDetailHeight(previousHeight);
      if (focusDetail) close.focus({ preventScroll: true });
    }

    function setOpen(open) {
      mark.setAttribute("aria-expanded", String(open));
      rail.toggleAttribute("data-open", open);
      recommendations.hidden = !open;
      if (open) rail.classList.toggle("rail-reveal", !reduce.matches);
      else {
        showingKore = false;
        select(-1);
        stopMotion();
      }
    }

    function stopMotion() {
      rail.classList.remove("rail-reveal");
    }

    if (autoOpen && listings.length > 0) {
      setOpen(true);
      const delay = reduce.matches ? 0 : 1220;
      setTimeout(() => {
        if (!recommendations.hidden && selected < 0 && !showingKore) {
          select(0, false, false);
        }
      }, delay);
    }
  }

  let trackerHost = null;

  async function toggleTrackerPanel() {
    if (trackerHost) {
      trackerHost.remove();
      trackerHost = null;
      return;
    }
    await injectFontFace();
    trackerHost = document.createElement("div");
    trackerHost.id = "cirkular-tracker-root";
    const shadow = trackerHost.attachShadow({ mode: "open" });

    const link = document.createElement("link");
    link.rel = "stylesheet";
    link.href = chrome.runtime.getURL("src/plugin.css");
    shadow.appendChild(link);

    const vars = document.createElement("style");
    vars.textContent = `:host {
      --wordmark-url: url("${chrome.runtime.getURL("assets/wordmark.png")}");
      --mark-url: url("${chrome.runtime.getURL("assets/mark.svg")}");
    }`;
    shadow.appendChild(vars);

    const panel = document.createElement("aside");
    panel.className = "tracker-panel";
    panel.setAttribute("aria-label", "CIRKULAR Tracker");
    panel.innerHTML = `
      <div class="tp-top">
        <div class="tp-brand">
          <span class="tp-mark" aria-hidden="true"></span>
          <span class="tp-wordmark" role="img" aria-label="CIRKULAR"></span>
        </div>
        <button class="tp-power" id="tp-power" type="button" aria-pressed="true">
          <span class="tp-dot" aria-hidden="true"></span>
          <span id="tp-power-label">Active</span>
        </button>
      </div>
      <div class="tp-tabs" role="tablist">
        <button class="tp-tab active" type="button" data-tab="tracker">Tracker</button>
        <button class="tp-tab" type="button" data-tab="saved" id="tp-saved-tab">Saved (0)</button>
      </div>
      <div class="tp-view active" id="tp-view-tracker">
        <div class="tp-hero">
          <span class="meta">Potential savings</span>
          <strong id="tp-dollars">$0</strong>
          <span class="tp-note">Based on finds you saved or viewed.</span>
        </div>
        <dl class="metrics">
          <div><dt>Evaluated</dt><dd id="tp-eval">0</dd></div>
          <div><dt>Saved finds</dt><dd id="tp-count">0</dd></div>
        </dl>
      </div>
      <div class="tp-view" id="tp-view-saved">
        <div class="tp-saved" id="tp-saved-list"></div>
      </div>
      <div class="tp-footer">
        <span class="meta">Zero tracking</span>
        <a href="${chrome.runtime.getURL("src/onboarding.html")}" target="_blank" rel="noopener">How it works</a>
      </div>
    `;
    shadow.appendChild(panel);
    document.documentElement.appendChild(trackerHost);

    const tabs = Array.from(shadow.querySelectorAll(".tp-tab"));
    const views = {
      tracker: shadow.getElementById("tp-view-tracker"),
      saved: shadow.getElementById("tp-view-saved")
    };
    tabs.forEach((t) => {
      t.addEventListener("click", () => {
        const k = t.dataset.tab;
        tabs.forEach((b) => b.classList.toggle("active", b === t));
        Object.entries(views).forEach(([vk, el]) => el.classList.toggle("active", vk === k));
      });
    });

    const powerBtn = shadow.getElementById("tp-power");
    const powerLabel = shadow.getElementById("tp-power-label");
    powerBtn.addEventListener("click", () => {
      chrome.storage.local.get({ enabled: true }, ({ enabled }) => {
        const next = !enabled;
        chrome.storage.local.set({ enabled: next }, () => {
          powerBtn.setAttribute("aria-pressed", String(next));
          powerLabel.textContent = next ? "Active" : "Paused";
        });
      });
    });

    function refreshTracker() {
      chrome.storage.local.get(
        { enabled: true, savedItems: [], stats: { evaluated: 0, savedDollars: 0 } },
        ({ enabled, savedItems, stats }) => {
          powerBtn.setAttribute("aria-pressed", String(enabled));
          powerLabel.textContent = enabled ? "Active" : "Paused";
          const pot = savedItems.reduce((s, x) => s + (Number(x.savings) || 0), 0);
          shadow.getElementById("tp-dollars").textContent = `$${Math.round((Number(stats.savedDollars) || 0) + pot)}`;
          shadow.getElementById("tp-eval").textContent = String(stats.evaluated || 0);
          shadow.getElementById("tp-count").textContent = String(savedItems.length);
          shadow.getElementById("tp-saved-tab").textContent = `Saved (${savedItems.length})`;

          const listEl = shadow.getElementById("tp-saved-list");
          if (!savedItems.length) {
            listEl.innerHTML = `<div class="tp-empty">No saved items yet.<br>Bookmark any secondhand find to save it here.</div>`;
            return;
          }
          listEl.innerHTML = savedItems
            .map((item, i) => `
              <div class="tp-saved-item">
                <img src="${item.image}" alt="">
                <div>
                  <a href="${item.url}" target="_blank" rel="noopener">${item.name}</a>
                  <div class="tp-saved-price">${item.price}<span>· ${item.source || "Poshmark"}</span></div>
                </div>
                <button class="tp-remove" type="button" data-rm="${i}" aria-label="Remove">×</button>
              </div>`)
            .join("");
          listEl.querySelectorAll("[data-rm]").forEach((btn) => {
            btn.addEventListener("click", () => {
              savedItems.splice(Number(btn.dataset.rm), 1);
              chrome.storage.local.set({ savedItems }, refreshTracker);
            });
          });
        }
      );
    }
    refreshTracker();

    const onOutside = (e) => {
      if (trackerHost && !e.composedPath().includes(trackerHost)) {
        trackerHost.remove();
        trackerHost = null;
        document.removeEventListener("mousedown", onOutside);
      }
    };
    setTimeout(() => document.addEventListener("mousedown", onOutside), 0);
  }

  chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
    if (msg?.type === "CIRKULAR_TOGGLE_TRACKER") {
      toggleTrackerPanel().then(() => sendResponse({ open: Boolean(trackerHost) }));
      return true;
    }
    if (msg?.type === "CIRKULAR_GET_STATUS") {
      sendResponse({
        mounted: Boolean(hostEl),
        product: detectedProduct,
        kore: detectedKore
      });
      return true;
    }
    if (msg?.type === "CIRKULAR_TOGGLE_PAGE") {
      if (hostEl) {
        unmountWidget();
        sendResponse({ mounted: false });
      } else {
        mountWidget(detectedProduct, { force: true }).then(() => sendResponse({ mounted: Boolean(hostEl) }));
      }
      return true;
    }
  });

  let lastUrl = location.href;
  let scanTimer = null;

  function scanAndMount() {
    if (isSecondhandSite) return;
    if (!chrome.runtime?.id) {
      if (scanTimer) clearInterval(scanTimer);
      return;
    }
    try {
      chrome.storage.local.get({ enabled: true }, ({ enabled }) => {
        if (chrome.runtime.lastError) return;
        const found = detectProductPage();
        if (found) {
          const changed = !detectedProduct || detectedProduct.name !== found.name;
          detectedProduct = found;
          if (changed) {
            liveListings = null;
            unmountWidget();
            if (enabled) mountWidget(detectedProduct);
          }
        }
      });
    } catch {
      if (scanTimer) clearInterval(scanTimer);
    }
  }

  scanAndMount();
  scanTimer = setInterval(() => {
    if (!chrome.runtime?.id) {
      clearInterval(scanTimer);
      return;
    }
    if (location.href !== lastUrl) {
      lastUrl = location.href;
      setTimeout(scanAndMount, 900);
    } else if (!detectedProduct) {
      scanAndMount();
    }
  }, 1500);
})();
