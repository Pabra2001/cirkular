// 100% local, zero-tracking on-device CLIP vision embedder (ONNX / WebGPU / WASM)
// Downloads quantized CLIP vision weights once into browser cache; falls back instantly to 176-dim HSV+HOG while warming up.

import { env, AutoProcessor, CLIPVisionModelWithProjection, RawImage } from "../lib/transformers.min.js";

env.allowLocalModels = false;
env.useBrowserCache = true;
env.backends.onnx.wasm.wasmPaths = chrome.runtime.getURL("lib/");
env.backends.onnx.wasm.numThreads = 1;

const MODEL_ID = "Xenova/clip-vit-base-patch32";
const clipCache = new Map();
const hsvHogCache = new Map();

let clipReady = null;
let clipLoading = false;
let clipFailed = false;

async function getClipPipeline() {
  if (clipReady) return clipReady;
  if (clipFailed || clipLoading) return null;
  clipLoading = true;
  try {
    const hasWebGpu = typeof navigator !== "undefined" && Boolean(navigator.gpu);
    const [processor, model] = await Promise.all([
      AutoProcessor.from_pretrained(MODEL_ID),
      CLIPVisionModelWithProjection.from_pretrained(MODEL_ID, {
        dtype: "q8",
        ...(hasWebGpu ? { device: "webgpu" } : {})
      }).catch(() => CLIPVisionModelWithProjection.from_pretrained(MODEL_ID, { dtype: "q8" }))
    ]);
    clipReady = { processor, model };
    return clipReady;
  } catch {
    clipFailed = true;
    return null;
  } finally {
    clipLoading = false;
  }
}

// Kick off background warmup immediately when the offscreen document opens
getClipPipeline();

function loadImage(url) {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.crossOrigin = "anonymous";
    img.onload = () => resolve(img);
    img.onerror = reject;
    img.src = url;
  });
}

async function fetchCroppedCanvas(imageUrl, catIdx = -1, size = 224) {
  const res = await fetch(imageUrl, { signal: AbortSignal.timeout(3000) });
  if (!res.ok) return null;
  const blob = await res.blob();
  const objUrl = URL.createObjectURL(blob);
  let img;
  try {
    img = await loadImage(objUrl);
  } finally {
    URL.revokeObjectURL(objUrl);
  }
  const sw = img.naturalWidth || img.width;
  const sh = img.naturalHeight || img.height;
  let rx = 0.08, ry = 0.08, rw = 0.84, rh = 0.84;
  if (catIdx === 0 || catIdx === 1 || catIdx === 5) {
    rx = 0.16; ry = 0.14; rw = 0.68; rh = 0.52;
  } else if (catIdx === 2 || catIdx === 4) {
    rx = 0.16; ry = 0.42; rw = 0.68; rh = 0.50;
  }
  const canvas = document.createElement("canvas");
  canvas.width = size;
  canvas.height = size;
  const ctx = canvas.getContext("2d", { willReadFrequently: true });
  ctx.drawImage(img, sw * rx, sh * ry, sw * rw, sh * rh, 0, 0, size, size);
  return canvas;
}

async function computeClipEmbedding(imageUrl, catIdx = -1) {
  if (!imageUrl || !clipReady) return null;
  const key = `${imageUrl}::${catIdx}`;
  if (clipCache.has(key)) return clipCache.get(key);
  try {
    const canvas = await fetchCroppedCanvas(imageUrl, catIdx, 224);
    if (!canvas) return null;
    const raw = RawImage.fromCanvas(canvas);
    const inputs = await clipReady.processor(raw);
    const { image_embeds } = await clipReady.model(inputs);
    const data = Array.from(image_embeds.data);
    let norm = 0;
    for (let i = 0; i < data.length; i++) norm += data[i] * data[i];
    norm = Math.sqrt(norm) || 1;
    for (let i = 0; i < data.length; i++) data[i] /= norm;
    if (clipCache.size > 160) clipCache.clear();
    clipCache.set(key, data);
    return data;
  } catch {
    return null;
  }
}

function rgbToHsv(r, g, b) {
  const rn = r / 255, gn = g / 255, bn = b / 255;
  const max = Math.max(rn, gn, bn);
  const min = Math.min(rn, gn, bn);
  const d = max - min;
  const s = max === 0 ? 0 : d / max;
  const v = max;
  let h = 0;
  if (d > 0) {
    if (max === rn) h = ((gn - bn) / d) % 6;
    else if (max === gn) h = (bn - rn) / d + 2;
    else h = (rn - gn) / d + 4;
    h *= 60;
    if (h < 0) h += 360;
  }
  return [h, s, v];
}

async function computeHsvHogEmbedding(imageUrl, catIdx = -1) {
  if (!imageUrl) return null;
  const key = `${imageUrl}::${catIdx}`;
  if (hsvHogCache.has(key)) return hsvHogCache.get(key);
  try {
    const size = 64;
    const canvas = await fetchCroppedCanvas(imageUrl, catIdx, size);
    if (!canvas) return null;
    const ctx = canvas.getContext("2d", { willReadFrequently: true });
    const { data } = ctx.getImageData(0, 0, size, size);

    const hsvHist = new Float32Array(48);
    const gray = new Float32Array(size * size);
    const corners = [0, (size - 1) * 4, (size - 1) * size * 4, (size * size - 1) * 4];
    let bgR = 0, bgG = 0, bgB = 0;
    for (const c of corners) { bgR += data[c]; bgG += data[c + 1]; bgB += data[c + 2]; }
    bgR /= 4; bgG /= 4; bgB /= 4;

    for (let y = 0; y < size; y++) {
      for (let x = 0; x < size; x++) {
        const off = (y * size + x) * 4;
        const r = data[off], g = data[off + 1], b = data[off + 2];
        const lum = 0.299 * r + 0.587 * g + 0.114 * b;
        gray[y * size + x] = lum;
        const sat = Math.max(r, g, b) - Math.min(r, g, b);
        const bgDistSq = (r - bgR) ** 2 + (g - bgG) ** 2 + (b - bgB) ** 2;
        if ((lum > 208 && sat < 24) || (bgDistSq < 784 && sat < 28)) continue;
        const [h, s, v] = rgbToHsv(r, g, b);
        hsvHist[Math.min(11, Math.floor(h / 30)) * 4 + (s >= 0.35 ? 1 : 0) * 2 + (v >= 0.5 ? 1 : 0)] += 1;
      }
    }

    const hog = new Float32Array(128);
    for (let y = 1; y < size - 1; y++) {
      const cy = Math.floor((y / size) * 4);
      for (let x = 1; x < size - 1; x++) {
        const cx = Math.floor((x / size) * 4);
        const gx = gray[y * size + (x + 1)] - gray[y * size + (x - 1)];
        const gy = gray[(y + 1) * size + x] - gray[(y - 1) * size + x];
        const mag = Math.hypot(gx, gy);
        if (mag < 6) continue;
        let angle = (Math.atan2(gy, gx) * 180) / Math.PI;
        if (angle < 0) angle += 180;
        hog[(cy * 4 + cx) * 8 + Math.min(7, Math.floor(angle / 22.5))] += mag;
      }
    }

    const norm = (arr) => {
      let s = 0;
      for (let i = 0; i < arr.length; i++) s += arr[i] * arr[i];
      const d = Math.sqrt(s) || 1;
      for (let i = 0; i < arr.length; i++) arr[i] /= d;
    };
    norm(hsvHist);
    norm(hog);

    const vec = { hsv: Array.from(hsvHist), hog: Array.from(hog) };
    if (hsvHogCache.size > 160) hsvHogCache.clear();
    hsvHogCache.set(key, vec);
    return vec;
  } catch {
    return null;
  }
}

function cosine(a, b) {
  let dot = 0;
  for (let i = 0; i < a.length; i++) dot += a[i] * b[i];
  return dot;
}

chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (msg?.type !== "CIRKULAR_OFFSCREEN_EMBED") return false;
  (async () => {
    // Use local CLIP vision model once ready; run sequentially on top candidates to avoid CPU spikes
    if (clipReady) {
      const retailClip = await computeClipEmbedding(msg.retailImage, msg.catIdx ?? -1);
      if (retailClip) {
        const scores = [];
        for (const u of (msg.candidateImages || []).slice(0, 6)) {
          const v = await computeClipEmbedding(u, -1);
          if (!v) {
            scores.push(null);
          } else {
            const sim = Math.max(0, Math.min(1, cosine(retailClip, v)));
            scores.push({ combined: sim, colorSim: sim, patternSim: sim, engine: "clip" });
          }
        }
        return { ok: true, scores, engine: "clip" };
      }
    } else {
      getClipPipeline();
    }

    const retailVec = await computeHsvHogEmbedding(msg.retailImage, msg.catIdx ?? -1);
    if (!retailVec) return { ok: false, scores: [] };
    const candVecs = await Promise.all(
      (msg.candidateImages || []).map((u) => computeHsvHogEmbedding(u, -1))
    );
    const scores = candVecs.map((v) => {
      if (!v) return null;
      const colorSim = cosine(retailVec.hsv, v.hsv);
      const patternSim = cosine(retailVec.hog, v.hog);
      return { combined: 0.55 * colorSim + 0.45 * patternSim, colorSim, patternSim, engine: "hsv-hog" };
    });
    return { ok: true, scores, engine: "hsv-hog" };
  })()
    .then((out) => sendResponse(out))
    .catch(() => sendResponse({ ok: false, scores: [] }));
  return true;
});
